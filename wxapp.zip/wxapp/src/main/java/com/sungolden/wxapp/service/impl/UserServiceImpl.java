package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.UserMapper;
import com.sungolden.wxapp.dto.User;
import com.sungolden.wxapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User findByOpenId(String open_id) {
        return userMapper.findByOpenId(open_id);
    }

    @Override
    public int insert(User user) {
        return userMapper.insert(user);
    }

    @Override
    public List<User> users() {
        return userMapper.users();
    }

    @Override
    public int updateInfo(User user) {
        return userMapper.updateInfo(user);
    }

    @Override
    public User getById(Integer id) {
        return userMapper.getById(id);
    }

    @Override
    public User findAccount(String accountString) {
        return userMapper.findAccount(accountString);
    }

    @Override
    public int delete(Integer[] ids) {
        return userMapper.deleteByPrimaryKey(ids);
    }
}
