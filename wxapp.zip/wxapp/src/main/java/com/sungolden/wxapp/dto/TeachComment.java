package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author zh
 * @date 2019-11-14
 */
@Data
public class TeachComment {
    /**
     * 评论编号
     */
    private String uid;

    /**
     * 用户编号
     */
    private Integer userId;

    /**
     * 圈子编号
     */
    private String invitationId;

    /**
     * 回复对象id
     */
    private Integer destId;

    /**
     * 回复内容
     */
    private String content;

    /**
     * 评论时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;

    /**
     * 是否删除
     */
    private Boolean isDelete;
    //新增属性
    private String wxNickName;
    /**
     * 评论人id
     */
    private String userName;
    /**
     * 回复对象id
     */
    private String destName;
}