package com.sungolden.wxapp.service.impl;

import com.sun.xml.internal.xsom.impl.scd.Iterators;
import com.sungolden.wxapp.dao.InvitationMapper;
import com.sungolden.wxapp.dto.GetYear;
import com.sungolden.wxapp.dto.Invitation;
import com.sungolden.wxapp.service.InvitationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class InvitationServiceImpl implements InvitationService {

    @Autowired
    private InvitationMapper invitationMapper;

    @Override
    public List<Invitation> getInvitation() {
        List<Invitation> invitation = invitationMapper.getInvitation();
        invitation.forEach(m -> {
            if (null == m.getPicture()) {
                m.setPicturesUrl(null);
            } else {
                m.setPicturesUrl(m.getPicture().split(","));
            }
        });
        return invitation;
    }

    @Override
    public List<Invitation> getExpert() {
        List<Invitation> expert = invitationMapper.getExpert();
        expert.forEach(m -> m.setPicturesUrl(m.getPicture().split(",")));
        return expert;
    }

    @Override
    public Invitation getByUid(String uid) {
        Invitation byUid = invitationMapper.getByUid(uid);
        if (null != byUid) {
            byUid.setPicturesUrl(byUid.getPicture().split(","));
        }
        return byUid;
    }

    @Override
    public int sendInvitation(Invitation invitation) {
        return invitationMapper.sendInvitation(invitation);
    }

    @Override
    public int delInvitation(String uid) {
        return invitationMapper.delInvitation(uid);
    }

    @Override
    public List<Invitation> myInvitation(Integer userId, String year) {
        Map<String, Object> map = new HashMap<>();
        map.put("userId", userId);
        map.put("year", year);
        List<Invitation> invitations = invitationMapper.myInvitation(map);
        invitations.forEach(m -> {
            if (null != m.getPicture()) {
                m.setPicturesUrl(m.getPicture().split(","));
            }
        });
        return invitations;
    }

    @Override
    public List<GetYear> getYear(Integer userId) {
        return invitationMapper.getYear(userId);
    }
}
