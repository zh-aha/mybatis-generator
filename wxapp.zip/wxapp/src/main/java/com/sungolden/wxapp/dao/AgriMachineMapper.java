package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.AgriMachine;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgriMachineMapper {
    int deleteByPrimaryKey(String uid);

    int insert(AgriMachine record);

    int insertSelective(AgriMachine record);

    AgriMachine selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(AgriMachine record);

    int updateByPrimaryKey(AgriMachine record);

    List<AgriMachine> getMachine();

    AgriMachine getByUid(String uid);

    //删除帖子
    int delInvitation(String uid);

    //发布帖子
    int sendInvitation(AgriMachine agriMachine);
}