package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * Feedback(意见反馈)
 *
 * @author zh
 * @date 2019-11-27
 */
@Data
public class Feedback {
    /**
     * 编号
     */
    private String uid;

    /**
     * 用户编号
     */
    private Integer userId;

    /**
     * 反馈内容
     */
    private String content;

    /**
     * 图片路径
     */
    private String pictures;
    /**
     * 反馈意见时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;

}