package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.AgriPolitics;

import java.util.List;

public interface AgriPoliticscService {
    List<AgriPolitics> getPoliticsList();

    AgriPolitics getByUid(String uid);

    void updateCount(Integer count, String uid);

    int postData(AgriPolitics agriPolitics);

    int update(AgriPolitics agriPolitics);

    int delete(String[] uids);

    List<AgriPolitics> getIndexNews();

}
