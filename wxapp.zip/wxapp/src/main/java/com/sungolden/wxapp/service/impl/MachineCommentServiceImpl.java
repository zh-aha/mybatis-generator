package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.MachineCommentMapper;
import com.sungolden.wxapp.dto.MachineComment;
import com.sungolden.wxapp.service.MachineCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MachineCommentServiceImpl implements MachineCommentService {

    @Autowired
    private MachineCommentMapper machineCommentMapper;

    @Override
    public List<String> getCommentByUid(String uid) {
        return machineCommentMapper.getCommentByUid(uid);
    }

    @Override
    public int sendCommemt(MachineComment machineComment) {
        return machineCommentMapper.sendComment(machineComment);
    }

    @Override
    public int delComment(String uid) {
        return machineCommentMapper.delComment(uid);
    }
}
