package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.AgriCounty;
import com.sungolden.wxapp.dto.Crop;
import com.sungolden.wxapp.service.AgriCountyService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.DateUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Description: 全县监测数据
 * @Author: zh
 * @CreateDate: 2019/11/27 15:03
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/27 15:03
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/agri_county")
public class AgriCountyController {

    @Autowired
    private AgriCountyService agriCountyService;

    /**
     * 全县监测数据 显示最新
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/default", method = RequestMethod.GET)
    public DataReturnResult countyData(String cid) {
        AgriCounty agriCounty = agriCountyService.countyData(cid);
        if (null == agriCounty) {
            return DataReturnResult.failure("0003", "无数据");
        }
        return DataReturnResult.success(agriCounty);
    }

    /**
     * 列表
     *
     * @param cid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public DataReturnResult list(String cid) {
        List<AgriCounty> agriCounties = agriCountyService.list(cid);
        return DataReturnResult.success(agriCounties);
    }

    /**
     * 列表 管理端
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/mlist", method = RequestMethod.GET)
    public DataReturnResult mlist(Integer pageNum) {
        if (ToolUtils.isBlank(pageNum)) {
            pageNum = 1;
        }
        //分页
        if (pageNum < 0 || pageNum == 0) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<AgriCounty> agriCounties = agriCountyService.mlist();
        PageInfo<AgriCounty> pageInfo = new PageInfo<>(agriCounties);
        return DataReturnResult.success(pageInfo);
    }

    /**
     * 添加
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public DataReturnResult post(@RequestBody AgriCounty agriCounty) {
        if (null != agriCounty) {
            if (ToolUtils.isBlank(agriCounty.getGrowth())) {
                return DataReturnResult.failure("0003", "长势值不能为空");
            }
            agriCounty.setUpdatetime(DateUtil.getNow());
            int i = agriCountyService.post(agriCounty);
            if (i == 1) {
                return DataReturnResult.success(i);
            }
            return DataReturnResult.failure("0003", "添加失败");
        }
        return DataReturnResult.failure("0003", "添加失败");
    }

    /**
     * 更新
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult update(@RequestBody AgriCounty agriCounty) {
        if (null != agriCounty) {
            if (ToolUtils.isBlank(agriCounty.getGrowth())) {
                return DataReturnResult.failure("0003", "长势值不能为空");
            }
            agriCounty.setUpdatetime(DateUtil.getNow());
            int i = agriCountyService.update(agriCounty);
            if (i == 1) {
                return DataReturnResult.success(i);
            }
            return DataReturnResult.failure("0003", "数据更新失败");
        }
        return DataReturnResult.failure("0003", "更新失败");
    }

    /**
     * 删除
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/del", method = RequestMethod.DELETE)
    public DataReturnResult delete(String[] uids) {
        if (ToolUtils.isBlank(uids)) {
            return DataReturnResult.failure("0003", "id不能为空");
        }
        int i = agriCountyService.delete(uids);
        return DataReturnResult.success(i);
    }

    /**
     * 农作物列表
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/crops", method = RequestMethod.GET)
    public DataReturnResult crops() {
        List<Crop> crops = agriCountyService.crops();
        return DataReturnResult.success(crops);
    }

    /**
     * 当前农作物
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/now", method = RequestMethod.GET)
    public DataReturnResult now() {
        Crop crop = agriCountyService.now();
        return DataReturnResult.success(crop);
    }
}
