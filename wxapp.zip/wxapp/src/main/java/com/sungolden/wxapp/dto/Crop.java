package com.sungolden.wxapp.dto;

import lombok.Data;

@Data
public class Crop {
    private String cid;
    private String cname;

    private String isPublish;
}
