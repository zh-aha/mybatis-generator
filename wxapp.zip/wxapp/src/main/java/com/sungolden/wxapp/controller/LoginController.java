package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.dto.CodeBody;
import com.sungolden.wxapp.dto.LoginBody;
import com.sungolden.wxapp.dto.User;
import com.sungolden.wxapp.service.RedisService;
import com.sungolden.wxapp.service.UserService;
import com.sungolden.wxapp.utils.*;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 登录
 * @Author: zh
 * @CreateDate: 2019/11/20 17:29
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/20 17:29
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/login")
public class LoginController {

    @Autowired
    private UserService userService;

    @Autowired
    private RedisService redisService;

    @Autowired
    private SystemConfig systemConfig;

    /**
     * @param
     * @return
     */
    @RequestMapping(value = "/wx_login", method = RequestMethod.POST)
    public DataReturnResult doLogin(
            @RequestBody CodeBody codeBody
            //    @RequestParam(value = "encrypteData",required = false) String encrypteData,
            //    @RequestParam(value = "iv",required = false) String iv
    ) {
        if (ToolUtils.isBlank(codeBody.getCode()) || ToolUtils.isBlank(codeBody.getRawData())) {
            return DataReturnResult.failure("0003", "参数不完整");
        }
        String code = codeBody.getCode();
        String rawData = codeBody.getRawData();
        JSONObject sessionKeyOrOpenId = getSessionKeyOrOpenId(code);
        //open_id
        String open_id = (String) sessionKeyOrOpenId.get("openid");
        //session_key
        String session_key = (String) sessionKeyOrOpenId.get("session_key");
        //自定义登录态 生成token

        //查询数据库是否存在openid
        if (ToolUtils.isBlank(open_id)) {
            return DataReturnResult.failure("0003", "登录失败");
        }
        User user = userService.findByOpenId(open_id);
        //判断user中是否存在open_id
        if (null == user) {
            JSONObject rawDataJson = JSONObject.fromObject(rawData);
            //入库
            String nickName = rawDataJson.getString("nickName"); //用户昵称
            String avatarUrl = rawDataJson.getString("avatarUrl"); //用户头像url
            Integer gender = Integer.valueOf(rawDataJson.getString("gender"));//性别
            String city = rawDataJson.getString("city");  //地区
            String country = rawDataJson.getString("country"); //国家
            String province = rawDataJson.getString("province"); //省份
            user = new User();
            user.setWxNickname(nickName);
            user.setIco(avatarUrl);
            user.setSex(gender);
            user.setWxAddress(country + "," + province + "," + city);
            user.setMessage(open_id);
            //保存用户信息
            int insert = userService.insert(user);
            if (insert == 0) {
                return DataReturnResult.failure("0003", "登录失败,稍后再试");
            }
            //Object token1 = redisService.getObj(user.getMessage());
            /*if (null != token1) {
                redisService.delObj(token1.toString());
            }*/
            //生成token 并将token存入redis
            TokenUtil instance = TokenUtil.getInstance();
            String token = instance.makeToken();
            //=====================================================
            //System.out.println("生成的token="+token);
            //=====================================================
            //缓存到redis
            redisService.setObj(token, token, 60 * 60 * 2);
            //token加密返回前端
            String encode = Base64Util.encode(token);
            User userInfo = userService.findByOpenId(open_id);
            Map<String, Object> map = new HashMap<>();
            userInfo.setMessage(null);
            //flag=1 微信头像 flag =2 自定义头像
            if (!ToolUtils.isBlank(userInfo.getIco()) && userInfo.getIco().contains("https")) {
                userInfo.setFlag(1);
            }
            map.put("userInfo", userInfo);
            map.put("token", encode);
            return DataReturnResult.success(map);
        } else {
            //用户信息已存在
            //Object token1 = redisService.getObj(user.getMessage());
            /*if (null != token1) {
                redisService.delObj(token1.toString());
            }*/
            //生成token 并将token存入redis
            TokenUtil instance = TokenUtil.getInstance();
            String token = instance.makeToken();
            //=====================================================
            //System.out.println("生成的token="+token);
            //=====================================================
            //缓存到redis
            redisService.setObj(token, token, 60 * 60 * 2);
            //token加密返回前端
            String encode = Base64Util.encode(token);
            User userInfo = userService.findByOpenId(open_id);
            userInfo.setMessage(null);
            Map<String, Object> map = new HashMap<>();
            //flag=1 微信头像 flag =2
            if (!ToolUtils.isBlank(userInfo.getIco()) && userInfo.getIco().contains("https")) {
                userInfo.setFlag(1);
                map.put("userInfo", userInfo);
                map.put("token", encode);
                return DataReturnResult.success(map);
            }
            userInfo.setFlag(2);
            map.put("userInfo", userInfo);
            map.put("token", encode);
            return DataReturnResult.success(map);
        }
    }

    //获取openid和sessionKey方法
    public JSONObject getSessionKeyOrOpenId(String code) {
        String requestUrl = "https://api.weixin.qq.com/sns/jscode2session";
        Map<String, String> requestUrlParam = new HashMap<>();
        requestUrlParam.put("appid", systemConfig.appid);//小程序appId
        requestUrlParam.put("secret", systemConfig.secret);
        requestUrlParam.put("js_code", code);//小程序端返回的code,前端传入
        requestUrlParam.put("grant_type", "authorization_code");//默认参数

        //发送post请求读取调用微信接口获取openid用户唯一标识
        String result = HttpClientUtil.doPost(requestUrl, requestUrlParam);
        JSONObject jsonObject = JSONObject.fromObject(result);
        // openid
        //String open_id = (String) jsonObject.get("openid");
        //查询数据库用户表是否存在open_id
        //User user = userInfoDao.queryUserInfoByOpenID(open_id);
        //session_key
        //String session_key = (String) jsonObject.get("session_key");
        return jsonObject;
    }

    /**
     * 后台管理登录
     *
     * @return
     */
    @RequestMapping(value = "/manager", method = RequestMethod.POST)
    public DataReturnResult login(@RequestBody LoginBody loginBody) {
        if (null == loginBody) {
            return DataReturnResult.failure("0003", "登录信息不能为空");
        }
        if (ToolUtils.isBlank(loginBody.getAccount())) {
            return DataReturnResult.failure("0003", "登录信息不能为空");
        }
        if (ToolUtils.isBlank(loginBody.getPassword())) {
            return DataReturnResult.failure("0003", "登录信息不能为空");
        }
        User user = userService.findAccount(loginBody.getAccount());
        if (null == user) {
            return DataReturnResult.failure("0003", "帐号或密码错误");
        }
        //base64加密
        String password = Base64Util.encode(loginBody.getPassword());
        Map<String, Object> map = new HashMap<>();
        if (password.equals(user.getPassword())) {
            //密码正确
            TokenUtil instance = TokenUtil.getInstance();
            String token = instance.makeToken();
            if (ToolUtils.isBlank(token)) {
                return DataReturnResult.failure("0003", "登录失败");
            }
            //token成功生成 缓存到reids
            redisService.setObj(token, token, 60 * 60 * 2);
            user.setMessage(null);
            map.put("users", user);
            map.put("m_token", token);
            return DataReturnResult.success(map);
        }
        return DataReturnResult.failure("0003", "登录失败");
    }

    @RequestMapping(value = "/ok", method = RequestMethod.GET)
    public DataReturnResult get() {
        return DataReturnResult.success("ok");
    }
}
