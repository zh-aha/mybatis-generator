package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.AgriSuggestion;
import com.sungolden.wxapp.dto.Phenological;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgriSuggestionMapper {
    int deleteByPrimaryKey(String uid);

    int insert(AgriSuggestion record);

    int insertSelective(AgriSuggestion record);

    AgriSuggestion selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(AgriSuggestion record);

    int updateByPrimaryKey(AgriSuggestion record);

    //管理建议
    AgriSuggestion getSuggestion(String cid, String pid);

    //单条、多条删除
    int delete(String[] uids);

    List<AgriSuggestion> list();

    Phenological getPid(String cid);
}