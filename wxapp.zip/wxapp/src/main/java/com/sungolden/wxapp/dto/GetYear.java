package com.sungolden.wxapp.dto;

import lombok.Data;

import java.util.List;

@Data
public class GetYear {

    private String years;

    private List<Invitation> invitations;
}
