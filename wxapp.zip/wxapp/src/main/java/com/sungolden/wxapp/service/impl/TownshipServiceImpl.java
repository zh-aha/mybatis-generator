package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.TownshipMapper;
import com.sungolden.wxapp.dto.Township;
import com.sungolden.wxapp.service.TownshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TownshipServiceImpl implements TownshipService {

    @Autowired
    private TownshipMapper townshipMapper;

    @Override
    public List<Township> getCity() {
        return townshipMapper.getCity();
    }

    @Override
    public List<Township> getContry(String code) {
        return townshipMapper.getCountry(code);
    }
}
