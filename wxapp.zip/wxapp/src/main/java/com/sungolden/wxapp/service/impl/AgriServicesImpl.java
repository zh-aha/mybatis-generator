package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.AgriServiceMapper;
import com.sungolden.wxapp.dto.AgriService;
import com.sungolden.wxapp.service.AgriServices;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgriServicesImpl implements AgriServices {

    @Autowired
    private AgriServiceMapper agriServiceMapper;

    @Override
    public List<AgriService> agriServiceList() {
        List<AgriService> agriServices = agriServiceMapper.agriServiceList();
        agriServices.forEach(m -> {
            if (!ToolUtils.isBlank(m.getPictures())) {
                m.setPicturesUrl(m.getPictures().split(","));
            }
        });
        return agriServices;
    }

    @Override
    public AgriService getByUid(String uid) {
        AgriService byUid = agriServiceMapper.getByUid(uid);
        if (null != byUid && null != byUid.getPictures()) {
            byUid.setPicturesUrl(byUid.getPictures().split(","));
        }
        return byUid;
    }

    @Override
    public int sendInvitation(AgriService agriService) {
        return agriServiceMapper.sendInvitation(agriService);
    }

    @Override
    public int delInvitation(String uid) {
        return agriServiceMapper.delInvitation(uid);
    }
}
