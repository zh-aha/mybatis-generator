package com.sungolden.wxapp.service;

import java.util.HashMap;

public interface RedisService {
    void setObj(String key, Object obj, long timeout);

    Object getObj(String key);

    void delObj(String key);

    HashMap<Object, Object> getRedis();
}
