package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * 专题地图服务
 *
 * @author zh
 * @date 2019-11-27
 */
@Data
public class MapTheme {
    /**
     * 编号
     */
    private String uid;

    /**
     * 服务名
     */
    private String name;

    /**
     * 专题类型
     */
    private String type;

    /**
     * 图层名称
     */
    private String layer;

    /**
     * 缩略图
     */
    private String thumb;

    /**
     * 数据日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;
    /**
     * 作物编号
     */
    private String cId;

    private String cname;

    private String url;

    private double growth;
    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }
}