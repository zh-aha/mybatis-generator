package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.MapBaseMapper;
import com.sungolden.wxapp.dto.MapBase;
import com.sungolden.wxapp.service.MapBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MapBaseServiceImpl implements MapBaseService {

    @Autowired
    private MapBaseMapper mapBaseMapper;

    @Override
    public MapBase mapBaseDefault() {
        return mapBaseMapper.mapBaseDefault();
    }

    @Override
    public MapBase nextMap(Integer order) {
        return mapBaseMapper.nextMap(order);
    }

    @Override
    public int postData(MapBase mapBase) {
        return mapBaseMapper.postData(mapBase);
    }

    @Override
    public Integer getOrderMin() {
        return mapBaseMapper.getOrderMin();
    }

    @Override
    public int delete(String[] uids) {
        return mapBaseMapper.deleteByPrimaryKey(uids);
    }

    @Override
    public List<MapBase> maps() {
        return mapBaseMapper.maps();
    }

    @Override
    public int update(MapBase mapBase) {
        return mapBaseMapper.updateByPrimaryKeySelective(mapBase);
    }
}
