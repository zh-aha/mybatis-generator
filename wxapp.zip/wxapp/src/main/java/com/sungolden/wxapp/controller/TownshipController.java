package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.Township;
import com.sungolden.wxapp.service.TownshipService;
import com.sungolden.wxapp.utils.DataReturnResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/city")
public class TownshipController {

    @Autowired
    private TownshipService townshipService;

    //@AuthCheck
    @RequestMapping(value = "/getCity", method = RequestMethod.GET)
    public DataReturnResult getCity() {
        List<Township> townships = townshipService.getCity();
        townships.forEach(m -> {
            m.setCountry(townshipService.getContry(m.getCode()));
        });
        return DataReturnResult.success(townships);
    }
}
