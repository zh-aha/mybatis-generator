package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.MapBase;
import com.sungolden.wxapp.dto.User;
import com.sungolden.wxapp.service.UserService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @Description: 用户信息类
 * @Author: zh
 * @CreateDate: 2019/11/20 15:55
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/20 15:55
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserInfoController userInfoController;

    /**
     * 获取所有用户列表
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/userInfo", method = RequestMethod.GET)
    public DataReturnResult users(Integer pageNum) {
        //分页
        if (ToolUtils.isBlank(pageNum)) {
            pageNum = 1;
        }
        if (pageNum < 0 || pageNum == 0) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<User> users = userService.users();
        PageInfo<User> pageInfo = new PageInfo(users);
        return DataReturnResult.success(pageInfo);
    }

    /**
     * 获取用户信息
     *
     * @param id
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/getById", method = RequestMethod.GET)
    public DataReturnResult getById(Integer id) {
        if (ToolUtils.isBlank(id)) {
            return DataReturnResult.failure("0003", "查询失败");
        }
        User user = userService.getById(id);
        return DataReturnResult.success(user);
    }

    /**
     * 修改用户信息
     *
     * @param user
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/updateInfo", method = RequestMethod.PUT)
    public DataReturnResult updateInfo(@RequestBody User user) {
        if (ToolUtils.isBlank(user.getId())) {
            return DataReturnResult.failure("0003", "修改失败");
        }
        //flag ==1 微信头像  flag == 2使用自定义头像
        if (ToolUtils.isBlank(user.getIco()) || user.getIco().contains("https")) {
            user.setWxIco(null);
            int i = userService.updateInfo(user);
            User byId = userService.getById(user.getId());
            byId.setFlag(1);
            return DataReturnResult.success(byId);
        }
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(user.getWxNickname());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = userService.updateInfo(user);
                if (i == 0) {
                    return DataReturnResult.failure("0000", "内容正常");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "昵称含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "修改失败");
        }
        User byId = userService.getById(user.getId());
        byId.setFlag(2);
        return DataReturnResult.success(byId);
    }
}
