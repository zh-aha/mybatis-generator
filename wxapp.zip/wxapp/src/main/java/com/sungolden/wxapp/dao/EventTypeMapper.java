package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.EventType;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventTypeMapper {
    int deleteByPrimaryKey(String uid);

    int insert(List<EventType> list);

    int insertSelective(EventType record);

    EventType selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(EventType record);

    int updateByPrimaryKey(EventType record);

    List<EventType> getNameList(String type);
}