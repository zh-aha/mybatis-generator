package com.sungolden.wxapp.controller;

import com.alibaba.druid.sql.visitor.functions.If;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.AgriMachine;
import com.sungolden.wxapp.service.AgriMachineService;
import com.sungolden.wxapp.service.FavoriteService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Description: 找农机租农机帖子信息
 * @Author: zh
 * @CreateDate: 2019/11/15 16:05
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/15 16:05
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/agri_machine")
public class AgriMachineController {

    protected Logger log = LoggerFactory.getLogger(AgriServiceController.class);

    @Autowired
    private AgriMachineService agriMachineService;
    @Autowired
    private FavoriteService favoriteService;
    @Autowired
    private UserInfoController userInfoController;

    /**
     * 所有农机帖子  默认按照租农机显示
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getMachine", method = RequestMethod.GET)
    public DataReturnResult getMachine(Integer userId) {
        log.info(">>>>>>>>>>>>>>>>>农机接口  所有农机帖子 默认按照租农机显示>>>>>>>>>>>>>>");
        if (null == userId) {
            List<AgriMachine> agriMachines = agriMachineService.getMachine();
            agriMachines.forEach(n -> {
                n.setFavorite(false);
            });
            return DataReturnResult.success(agriMachines);
        }
        List<AgriMachine> agriMachines = agriMachineService.getMachine();
        agriMachines.forEach(n -> {
            boolean favorite = favoriteService.isFavorite(n.getUid(), userId);
            n.setFavorite(favorite);
        });
        return DataReturnResult.success(agriMachines);
    }

    /**
     * 获取某个帖子详情
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getByUid(String uid) {
        log.info(">>>>>>>>>>>>>>>>>农机接口  获取某个帖子详情 uid=" + uid + ">>>>>>>>>>>>>>");
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        AgriMachine byUid = agriMachineService.getByUid(uid);
        if (null == byUid) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        return DataReturnResult.success(byUid);
    }

    /**
     * 发农机帖接口
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/sendInvitation", method = RequestMethod.POST)
    public DataReturnResult sendInvitation(@RequestBody AgriMachine agriMachine) {
        log.info(">>>>>>>>>>>>>>>>>农机接口  发农机帖接口>>>>>>>>>>>>>>");
        if (ToolUtils.isBlank(agriMachine.getUserId())) {
            return DataReturnResult.failure("0003", "发帖失败输入用户id");
        }
       /* //此处前端需判断是否有内容，无内容提示用户输入，否则无法发送
        if (ToolUtils.isBlank(agriMachine.getType())){
            return DataReturnResult.failure("0003","请选择找农机或租农机");
        }*/
        if (ToolUtils.isBlank(agriMachine.getContent())) {
            return DataReturnResult.failure("0003", "发布内容为空,请输入内容");
        }
        /*if (!ToolUtils.isBlank(agriMachine.getAddress())) {
            if (ToolUtils.isBlank(agriMachine.getLocation())) {
                return DataReturnResult.failure("0003", "请选择位置");
            }
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String datetime = sdf.format(date);
        agriMachine.setUpdatetime(datetime);
        agriMachine.setIsDelete(false);
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(agriMachine.getContent());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = agriMachineService.sendInvitation(agriMachine);
                if (i == 0) {
                    return DataReturnResult.failure("0003", "发送失败");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "内容含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "发送失败");
        }
        return DataReturnResult.failure("0003", "发送失败");
    }

    /**
     * 删除农机帖子
     *
     * @param uid
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delInvitation", method = RequestMethod.DELETE)
    public DataReturnResult delInvitation(String uid) {
        log.info(">>>>>>>>>>>>>>>>>农机接口  删除农机帖子 uid=" + uid + ">>>>>>>>>>>>>>");
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "删除失败,无帖子id");
        }

        int i = agriMachineService.delInvitation(uid);
        if (i == 0) {
            return DataReturnResult.failure("0003", "删除失败,请重试");
        }
        return DataReturnResult.success(i);
    }
}
