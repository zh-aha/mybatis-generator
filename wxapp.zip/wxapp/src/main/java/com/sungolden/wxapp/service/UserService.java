package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.User;

import java.util.List;

public interface UserService {

    User findByOpenId(String open_id);

    int insert(User user);

    List<User> users();

    //修改
    int updateInfo(User user);

    //获取用户信息
    User getById(Integer id);

    //查找用户
    User findAccount(String accountString);

    int delete(Integer[] ids);
}
