package com.sungolden.wxapp.utils;

import sun.misc.BASE64Encoder;

import javax.xml.crypto.Data;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * Description:Token生成工具
 * 第一部分我们称它为头部（header),第二部分我们称其为载荷（payload, 类似于飞机上承载的物品)，第三部分是签证（signature).
 * Auth: Frank
 * Date: 2017-11-02
 * Time: 下午 5:05
 */
public class TokenUtil {

    /*
     * 单例设计模式（保证类的对象在内存中只有一个）1、把类的构造函数私有2、自己创建一个类的对象3、对外提供一个公共的方法，返回类的对象
     */
    private TokenUtil() {

    }

    ;


    private static final TokenUtil instance = new TokenUtil();

    /**
     * 返回类的对象
     *
     * @return
     */
    public static TokenUtil getInstance() {
        return instance;
    }

    /**
     * 生成Token Token：Nv6RRuGEVvmGjB+jimI/gw==
     *
     * @return
     */
    public String makeToken() { // checkException
        // 7346734837483 834u938493493849384 43434384
        String token = UUID.randomUUID().toString().replaceAll("-", "") + "";
        // 数据指纹 128位长 16个字节 md5
        try {
            MessageDigest md = MessageDigest.getInstance("md5");
            byte md5[] = md.digest(token.getBytes());
            // base64编码--任意二进制编码明文字符 adfsdfsdfsf
            BASE64Encoder encoder = new BASE64Encoder();
            String encode = encoder.encode(md5);
            String now = new Date().toString();
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return encode + "," + df.format(new Date());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        String s = TokenUtil.getInstance().makeToken();
        System.out.println("token=" + s);
    }


}

