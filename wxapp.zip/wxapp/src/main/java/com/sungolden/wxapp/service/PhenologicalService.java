package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.EventType;
import com.sungolden.wxapp.dto.Phenological;

import java.util.List;

public interface PhenologicalService {
    List<Phenological> getAll(String crop);

    Phenological getByUid(String uid);

    int insert(Phenological phenological);

    List<Phenological> list();

    int update(Phenological phenological);

    int delete(String[] uids);

    List<EventType> enventList();
}
