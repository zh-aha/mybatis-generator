package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.AgriCountyMapper;
import com.sungolden.wxapp.dto.AgriCounty;
import com.sungolden.wxapp.dto.Crop;
import com.sungolden.wxapp.service.AgriCountyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgriCountyServiceImpl implements AgriCountyService {

    @Autowired
    private AgriCountyMapper agriCountyMapper;

    @Override
    public AgriCounty countyData(String cid) {
        return agriCountyMapper.countyData(cid);
    }

    @Override
    public List<AgriCounty> list(String cid) {
        return agriCountyMapper.list(cid);
    }

    @Override
    public int post(AgriCounty agriCounty) {
        return agriCountyMapper.post(agriCounty);
    }

    @Override
    public int delete(String[] uids) {
        return agriCountyMapper.delete(uids);
    }

    @Override
    public int update(AgriCounty agriCounty) {
        return agriCountyMapper.updateByPrimaryKeySelective(agriCounty);
    }

    @Override
    public List<Crop> crops() {
        return agriCountyMapper.crops();
    }

    @Override
    public Crop now() {
        return agriCountyMapper.now();
    }

    @Override
    public List<AgriCounty> mlist() {
        return agriCountyMapper.mlist();
    }
}
