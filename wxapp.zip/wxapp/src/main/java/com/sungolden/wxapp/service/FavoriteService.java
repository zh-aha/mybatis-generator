package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.Favorite;

import java.util.List;

public interface FavoriteService {
    int insert(Favorite favorite);

    int delete(String uid, Integer userId);

    List<Favorite> getListByUserId(Integer userId);

    boolean isFavorite(String uid, Integer userId);

    Favorite checkFavorite(String invitationId, Integer userId);
}
