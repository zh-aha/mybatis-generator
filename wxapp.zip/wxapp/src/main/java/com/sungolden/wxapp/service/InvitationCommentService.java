package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.InvitationComment;

import java.util.List;

public interface InvitationCommentService {
    List<String> getCommentByUid(String uid);

    int delComment(String uid);

    int sendCommemt(InvitationComment invitationComment);
}
