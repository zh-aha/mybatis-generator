package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.List;

/**
 * @author zh
 * @date 2019-11-20
 */
@Data
public class Favorite {
    /**
     * 编号
     */
    private String uid;

    /**
     * 用户编号
     */
    private Integer userId;

    /**
     * 文章编号
     */
    private String invitationId;

    /**
     * 文章类型
     */
    private Integer type;

    /**
     * 简介
     */
    private String summary;

    /**
     * 收藏数间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;

    private Integer favId;

    private Invitation invitation;
    private AgriMachine agriMachine;
    private AgriService agriService;
    private AgriTeacher agriTeacher;
    private AgriPolitics agriPolitic;

}