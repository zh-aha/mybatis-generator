package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.Demo;

import java.util.List;

public interface DemoService {

    public List<Demo> demo();
}
