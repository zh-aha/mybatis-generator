package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.*;
import com.sungolden.wxapp.service.*;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.DateUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @Description: 收藏
 * @Author: zh
 * @CreateDate: 2019/11/20 14:46
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/20 14:46
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/favorite")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    @Autowired
    private AgriTeacherService agriTeacherService;

    @Autowired
    private AgriMachineService agriMachineService;

    @Autowired
    private AgriServices agriServices;

    @Autowired
    private InvitationService invitationService;

    @Autowired
    private AgriPoliticscService agriPoliticscService;

    /**
     * 收藏
     *
     * @param favorite type: 1农师 2农机 3农服 4圈子 5农政
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public DataReturnResult insert(@RequestBody Favorite favorite) {
        if (ToolUtils.isBlank(favorite.getType()) ||
                ToolUtils.isBlank(favorite.getUserId()) ||
                ToolUtils.isBlank(favorite.getFavId()) ||
                ToolUtils.isBlank(favorite.getInvitationId())
        ) {
            return DataReturnResult.failure("0003", "收藏失败");
        }
        Favorite fa = favoriteService.checkFavorite(favorite.getInvitationId(), favorite.getUserId());
        if (null != fa) {
            return DataReturnResult.success(1);
        }
        favorite.setUpdatetime(DateUtil.getNow());
        int i = favoriteService.insert(favorite);
        return DataReturnResult.success(i);
    }

    /**
     * 取消收藏
     *
     * @param uid 收藏编号
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public DataReturnResult delete(String uid, Integer userId) {
        if (ToolUtils.isBlank(uid) || ToolUtils.isBlank(userId)) {
            return DataReturnResult.failure("0003", "取消失败");
        }
        int i = favoriteService.delete(uid, userId);
        return DataReturnResult.success(i);
    }

    /**
     * 该用户收藏列表
     *
     * @param userId
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/getFavorites", method = RequestMethod.GET)
    public DataReturnResult getListByUserId(Integer userId) {
        if (ToolUtils.isBlank(userId)) {
            return DataReturnResult.failure("0003", "userId为空");
        }
        List<Favorite> favorites = favoriteService.getListByUserId(userId);
        favorites.forEach(n -> {
            Integer type = n.getType();
            //农师
            if (!ToolUtils.isBlank(type) && type == 1) {
                AgriTeacher byUid = agriTeacherService.getByUid(n.getInvitationId());
                if (null != byUid) {
                    byUid.setFavorite(true);
                    n.setAgriTeacher(byUid);
                }
            }
            //农机
            if (!ToolUtils.isBlank(type) && type == 2) {
                AgriMachine byUid = agriMachineService.getByUid(n.getInvitationId());
                if (null != byUid) {
                    byUid.setFavorite(true);
                    n.setAgriMachine(byUid);
                }
            }
            //农服
            if (!ToolUtils.isBlank(type) && type == 3) {
                AgriService byUid = agriServices.getByUid(n.getInvitationId());
                if (null != byUid) {
                    byUid.setFavorite(true);
                    n.setAgriService(byUid);
                }
            }
            //圈子
            if (!ToolUtils.isBlank(type) && type == 4) {
                Invitation byUid = invitationService.getByUid(n.getInvitationId());
                if (null != byUid) {
                    byUid.setFavorite(true);
                    n.setInvitation(byUid);
                }
            }
            //农政
            if (!ToolUtils.isBlank(type) && type == 5) {
                AgriPolitics byUid = agriPoliticscService.getByUid(n.getInvitationId());
                if (null != byUid) {
                    byUid.setFavorite(true);
                    n.setAgriPolitic(byUid);
                }
            }
        });
        return DataReturnResult.success(favorites);
    }

    /**
     * 查看收藏帖子详细内容
     *
     * @param circle 圈子编号
     * @param type   文章类型  type: 1农师 2农机 3农服 4圈子
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/getInvitation", method = RequestMethod.GET)
    public DataReturnResult getFavoriteDetial(String circle, Integer type) {
        if (ToolUtils.isBlank(circle) || ToolUtils.isBlank(type)) {
            return DataReturnResult.failure("0003", "查看失败");
        }
        //农师
        if (type == 1) {
            AgriTeacher byUid = agriTeacherService.getByUid(circle);
            return DataReturnResult.success(byUid);
        }
        //农机
        if (type == 2) {
            AgriMachine byUid = agriMachineService.getByUid(circle);
            return DataReturnResult.success(byUid);
        }
        //农服
        if (type == 3) {
            AgriService byUid = agriServices.getByUid(circle);
            return DataReturnResult.success(byUid);
        }
        //圈子
        if (type == 4) {
            Invitation byUid = invitationService.getByUid(circle);
            return DataReturnResult.success(byUid);
        }
        //农政
        if (type == 5) {
            AgriPolitics byUid = agriPoliticscService.getByUid(circle);
            return DataReturnResult.success(byUid);
        }
        return DataReturnResult.failure("0003", "查看内容失败");
    }

    public DataReturnResult isFavorite() {
        return DataReturnResult.success("");
    }
}
