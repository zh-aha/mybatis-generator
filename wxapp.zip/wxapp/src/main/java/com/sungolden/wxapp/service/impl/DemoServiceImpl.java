package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.DemoMapper;
import com.sungolden.wxapp.dto.Demo;
import com.sungolden.wxapp.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DemoServiceImpl implements DemoService {

    @Autowired
    private DemoMapper demoMapper;

    @Override
    public List<Demo> demo() {
        return demoMapper.demo();
    }
}
