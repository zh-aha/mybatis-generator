package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.Favorite;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FavoriteMapper {
    //取消收藏
    int deleteByPrimaryKey(String uid, Integer userId);

    //收藏
    int insert(Favorite record);

    int insertSelective(Favorite record);

    Favorite selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(Favorite record);

    int updateByPrimaryKey(Favorite record);

    //收藏列表
    List<Favorite> getListByUserId(Integer userId);

    Favorite select(String uid, Integer userId);

    Favorite checkFavorite(String invitationId, Integer userId);
}