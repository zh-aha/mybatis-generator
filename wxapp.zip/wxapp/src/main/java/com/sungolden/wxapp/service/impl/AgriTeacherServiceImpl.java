package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.AgriTeacherMapper;
import com.sungolden.wxapp.dto.AgriTeacher;
import com.sungolden.wxapp.service.AgriTeacherService;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgriTeacherServiceImpl implements AgriTeacherService {
    @Autowired
    private AgriTeacherMapper agriTeacherMapper;

    @Override
    public List<AgriTeacher> agriTeacherList() {
        List<AgriTeacher> agriTeachers = agriTeacherMapper.agriTeacherList();
        agriTeachers.forEach(m -> {
            if (!ToolUtils.isBlank(m.getPictures())) {
                m.setPicturesUrl(m.getPictures().split(","));
            }
        });
        return agriTeachers;
    }

    @Override
    public int sendInvitation(AgriTeacher agriTeacher) {
        return agriTeacherMapper.sendInvitation(agriTeacher);
    }

    @Override
    public int delInvitation(String uid) {
        return agriTeacherMapper.delInvitation(uid);
    }

    @Override
    public AgriTeacher getByUid(String uid) {
        AgriTeacher byUid = agriTeacherMapper.getByUid(uid);
        if (null != byUid && null != byUid.getPictures()) {
            byUid.setPicturesUrl(byUid.getPictures().split(","));
        }
        return byUid;
    }
}
