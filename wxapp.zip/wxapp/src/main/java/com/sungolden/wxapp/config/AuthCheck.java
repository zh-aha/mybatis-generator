package com.sungolden.wxapp.config;

import java.lang.annotation.*;

/**
 * 权限校验注解  作用于方法
 */
@Inherited
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AuthCheck {
    int intVal() default 5;

    String stringVal() default "";
}
