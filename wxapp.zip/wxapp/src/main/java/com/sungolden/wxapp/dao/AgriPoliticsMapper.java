package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.AgriPolitics;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgriPoliticsMapper {
    int deleteByPrimaryKey(String uid);

    int insert(AgriPolitics record);

    int insertSelective(AgriPolitics record);

    AgriPolitics selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(AgriPolitics record);

    int updateByPrimaryKey(AgriPolitics record);

    List<AgriPolitics> getPoliticsList();

    AgriPolitics getByUid(String uid);

    void updateCount(@Param("viewCount") Integer viewCount, @Param("uid") String uid);

    int postData(AgriPolitics agriPolitics);

    int delete(String[] uids);

    List<AgriPolitics> getIndexNews(String[] uids);

}