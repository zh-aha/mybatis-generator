package com.sungolden.wxapp.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class ToolUtils {

    /**
     * 字符串为空，给默认值
     *
     * @param str
     * @param defaultValue
     * @return <p>
     * @author zh
     * @since 2016年5月25日 下午4:27:12
     */
    public static String nullDefaultValue(String str, String defaultValue) {
        if (str == null) {
            return defaultValue;
        } else {
            return str;
        }
    }

    /**
     * 字符串为空，给默认值 方法说明
     *
     * @param data
     * @param defaultValue
     * @return <p>
     * @author zh
     * @since 2016年5月25日 下午4:43:30
     */
    public static int nullDefaultValue(Integer data, int defaultValue) {
        if (data == null) {
            return defaultValue;
        } else {
            return data;
        }
    }

    public static String nullDefaultValue(Object data, String defaultValue) {
        if (data == null) {
            return defaultValue;
        }
        if (Boolean.class.isInstance(data)) {
            return data.toString();
        } else if (Date.class.isInstance(data)) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return sdf.format(data);
        } else {
            return data.toString();
        }


    }

    /**
     * 字符串超过长度截取
     *
     * @param str
     * @param standardLength 标准长度
     * @param replace        超长截取后添加的尾串
     * @return <p>
     * @author zh
     * @since 2016年6月8日 下午2:08:36
     */
    public static String cutOverLengthStr(String str, int standardLength, String replace) {
        if (str == null) {
            return "";
        } else {
            if (str.length() > standardLength) {
                return str.substring(0, standardLength) + replace;
            }
            return str;
        }
    }

    /**
     * 字符串是否为空(null或"")
     * <p>
     *
     * @return
     */
    public static boolean isEmpty(String str) {
        if (str == null) {
            return true;
        }
        if (str.length() == 0) {
            return true;
        }
        return false;
    }

    /**
     * 字符串是否为空(null或""或" ")
     * <p>
     *
     * @return
     */
    public static boolean isBlank(String str) {
        if (str == null) {
            return true;
        }
        if (str.trim().length() == 0) {
            return true;
        }

        return false;
    }

    /**
     * 对象是否为空
     *
     * @param object
     * @return
     * @author 2016年6月12日 下午3:15:34
     */
    public static boolean isBlank(Object object) {
        if (object == null) {
            return true;
        }
        if (object.toString().trim().length() == 0) {
            return true;
        }

        return false;
    }

    public static void main(String[] args) {
        String curMethordName = getCurMethordName(null);
        System.out.println(curMethordName);
        System.out.println("*********************");
        System.out.println(getStringRandom(12));
    }

    /**
     * 获取调用此方法的方法名
     * <p>
     *
     * @param separator分割符
     * @return
     */
    public static String getCurMethordName(String separator) {
        String tempSeparator = null;
        if (separator == null) {
            tempSeparator = ":";
        } else {
            tempSeparator = separator;
        }
        StackTraceElement curElement = Thread.currentThread().getStackTrace()[2];
        String classFullName = curElement.getClassName();
        int lastLocal = classFullName.lastIndexOf(".");

        String className = classFullName.substring(lastLocal + 1);
        String methordName = curElement.getMethodName();
        return className + tempSeparator + methordName;
    }

    // 生成随机数字和字母,
    public static String getStringRandom(int length) {

        String val = "";
        Random random = new Random();

        // 参数length，表示生成几位随机数
        for (int i = 0; i < length; i++) {

            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            // 输出字母还是数字
            if ("char".equalsIgnoreCase(charOrNum)) {
                // 输出是大写字母还是小写字母
                int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (random.nextInt(26) + temp);
            } else if ("num".equalsIgnoreCase(charOrNum)) {
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }

}
