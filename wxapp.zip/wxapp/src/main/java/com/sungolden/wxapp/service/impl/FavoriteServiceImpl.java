package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.FavoriteMapper;
import com.sungolden.wxapp.dto.Favorite;
import com.sungolden.wxapp.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteMapper favoriteMapper;

    @Override
    public int insert(Favorite favorite) {
        return favoriteMapper.insert(favorite);
    }

    @Override
    public int delete(String uid, Integer userId) {
        return favoriteMapper.deleteByPrimaryKey(uid, userId);
    }

    @Override
    public List<Favorite> getListByUserId(Integer userId) {
        return favoriteMapper.getListByUserId(userId);
    }

    @Override
    public boolean isFavorite(String uid, Integer userId) {
        Favorite favorite = favoriteMapper.select(uid, userId);
        if (null == favorite) {
            return false;
        }
        return true;
    }

    @Override
    public Favorite checkFavorite(String invitationId, Integer userId) {
        return favoriteMapper.checkFavorite(invitationId, userId);
    }
}
