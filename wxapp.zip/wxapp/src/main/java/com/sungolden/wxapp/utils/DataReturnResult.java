package com.sungolden.wxapp.utils;

import lombok.Data;

import java.io.Serializable;

/**
 * 返回数据结果类
 */
@Data
public class DataReturnResult<T> implements Serializable {
    private String code;
    private String message;
    private String sys_message;//调试信息
    private T data;
    private Throwable throwable;

    public T getData() {
        return data;
    }

    /*
        成功code
     */
    public static final String SUCCESS_CODE = "0000";
    /*
        系统异常code    其他业务校验异常自定义code值，通过接口文档说明
     */
    public static final String FAILURE_CODE = "0001";

    /*
        系统异常code    其他业务校验异常自定义code值，通过接口文档说明
     */
    public static final String EXCEPTION_CODE = "系统繁忙！";

    private DataReturnResult() {
    }

    private DataReturnResult(String code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    private DataReturnResult(String code, String message, Throwable throwable) {
        this.code = code;
        this.message = message;
        this.throwable = throwable;
    }

    private DataReturnResult(String code, T data) {
        this.code = code;
        this.data = data;
    }

    private DataReturnResult(String code, String message) {
        this.code = code;
        this.message = message;
    }

    private DataReturnResult(String code, String message, String sys_message) {
        this.code = code;
        this.message = message;
        this.sys_message = sys_message;
    }

    public static <T> DataReturnResult<T> success(T data) {
        return new DataReturnResult<T>(SUCCESS_CODE, data);
    }

    public static <T> DataReturnResult<T> failure(String message, Throwable throwable) {
        return new DataReturnResult<T>(FAILURE_CODE, message, throwable);
    }

    public static <T> DataReturnResult<T> failure(String message) {
        return new DataReturnResult<T>(FAILURE_CODE, message);
    }

    /**
     * 自定义业务异常返回方法
     *
     * @param code
     * @param message
     * @param <T>
     * @return
     */
    public static <T> DataReturnResult<T> failure(String code, String message, String sys_message) {
        return new DataReturnResult<T>(code, message, sys_message);
    }

    /**
     * 自定义业务异常返回方法
     *
     * @param code
     * @param message
     * @param <T>
     * @return
     */
    public static <T> DataReturnResult<T> failure(String code, String message) {
        return new DataReturnResult<T>(code, message);
    }
}
