package com.sungolden.wxapp.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SystemConfig {

    @Value("${value.appid}")
    public String appid;
    @Value("${value.secret}")
    public String secret;
    @Value("${value.url}")
    public String url;
}
