package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.Township;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TownshipMapper {
    int deleteByPrimaryKey(String code);

    int insert(Township record);

    int insertSelective(Township record);

    Township selectByPrimaryKey(String code);

    int updateByPrimaryKeySelective(Township record);

    int updateByPrimaryKey(Township record);

    List<Township> getCity();

    List<Township> getCountry(String code);
}