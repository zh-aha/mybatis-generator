package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.MapBase;

import java.util.List;

public interface MapBaseService {

    MapBase mapBaseDefault();

    MapBase nextMap(Integer order);

    int postData(MapBase mapBase);

    Integer getOrderMin();

    int delete(String[] uids);

    List<MapBase> maps();

    int update(MapBase mapBase);
}
