package com.sungolden.wxapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 配置类
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(mysHandlerInterceptor()).addPathPatterns("/**");
    }

    @Bean
    public MyHandlerInterceptor mysHandlerInterceptor() {
        return new MyHandlerInterceptor();
    }
}
