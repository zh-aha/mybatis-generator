package com.sungolden.wxapp.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zh
 * @date 2019-11-14
 */
@Data
public class Calamity {
    /**
     * 编号
     */
    private String uid;

    /**
     * 近期农事，易发病害，易发虫害，易发草害
     */
    private String type;

    /**
     * 标题
     */
    private String title;

    /**
     * 缩略图
     */
    private String thumbnail;

    /**
     * 简介
     */
    private String summary;

    /**
     * 文章内容，<p>text<p><img src=""/>
     */
    private String content;

    private String name;

    private String pname;

    private String cname;

    private String phenologicalId;

    private String cropId;

    private String eid;

}