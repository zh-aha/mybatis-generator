package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.InvitationComment;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvitationCommentMapper {
    int deleteByPrimaryKey(String uid);

    int insert(InvitationComment record);

    int insertSelective(InvitationComment record);

    InvitationComment selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(InvitationComment record);

    int updateByPrimaryKey(InvitationComment record);

    //获取评论列表
    List<String> getCommentByUid(String uid);

    //删除评论
    int delComment(String uid);

    //评论
    int sendCommemt(InvitationComment invitationComment);
}