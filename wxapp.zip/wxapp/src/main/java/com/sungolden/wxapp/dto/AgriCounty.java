package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author zh
 * @date 2019-11-27
 */
public class AgriCounty {
    /**
     * 编号
     */
    private String uid;

    /**
     * 长势
     */
    private Float growth;

    /**
     * 墒情
     */
    private Float soil;

    /**
     * 产量
     */
    private Float yield;

    /**
     * 数据日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;
    /**
     * 作物编号
     */

    private String cId;

    private String cname;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Float getGrowth() {
        return growth;
    }

    public void setGrowth(Float growth) {
        this.growth = growth;
    }

    public Float getSoil() {
        return soil;
    }

    public void setSoil(Float soil) {
        this.soil = soil;
    }

    public Float getYield() {
        return yield;
    }

    public void setYield(Float yield) {
        this.yield = yield;
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime;
    }

    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }
}