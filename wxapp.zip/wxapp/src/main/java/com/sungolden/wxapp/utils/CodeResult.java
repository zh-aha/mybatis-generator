package com.sungolden.wxapp.utils;

/**
 * 返回码
 */
public enum CodeResult {
    SUCCESS(0), FAILURE(-1);

    int var;

    CodeResult(int var) {
        this.var = var;
    }

    int getValue() {
        return this.var;
    }

    public String toString() {
        return this.getValue() + "";
    }
}
