package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.GetYear;
import com.sungolden.wxapp.dto.Invitation;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface InvitationMapper {
    int deleteByPrimaryKey(String uid);

    int insert(Invitation record);

    int insertSelective(Invitation record);

    Invitation selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(Invitation record);

    int updateByPrimaryKey(Invitation record);

    //获取普通帖子
    List<Invitation> getInvitation();

    //获取专家帖子
    List<Invitation> getExpert();

    //根据帖子编号获取帖子内容
    Invitation getByUid(String uid);

    //发帖子
    int sendInvitation(Invitation invitation);

    //删除帖子
    int delInvitation(String uid);

    //我发布的
    List<Invitation> myInvitation(Map<String, Object> map);

    List<GetYear> getYear(Integer userId);
}