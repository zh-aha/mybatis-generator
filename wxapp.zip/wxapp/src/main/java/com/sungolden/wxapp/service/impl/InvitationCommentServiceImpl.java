package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.InvitationCommentMapper;
import com.sungolden.wxapp.dto.InvitationComment;
import com.sungolden.wxapp.service.InvitationCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvitationCommentServiceImpl implements InvitationCommentService {

    @Autowired
    private InvitationCommentMapper invitationCommentMapper;

    @Override
    public List<String> getCommentByUid(String uid) {
        return invitationCommentMapper.getCommentByUid(uid);
    }

    @Override
    public int delComment(String uid) {
        return invitationCommentMapper.delComment(uid);
    }

    @Override
    public int sendCommemt(InvitationComment invitationComment) {
        return invitationCommentMapper.sendCommemt(invitationComment);
    }
}
