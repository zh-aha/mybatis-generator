package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.Feedback;

import java.util.List;

public interface FeedbackService {
    List<Feedback> getList();

    int insert(Feedback feedback);
}
