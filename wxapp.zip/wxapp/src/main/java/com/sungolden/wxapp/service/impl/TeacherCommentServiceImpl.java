package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.TeachCommentMapper;
import com.sungolden.wxapp.dto.TeachComment;
import com.sungolden.wxapp.service.TeacherCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherCommentServiceImpl implements TeacherCommentService {

    @Autowired
    private TeachCommentMapper teachCommentMapper;

    @Override
    public List<String> getCommentByUid(String uid) {
        return teachCommentMapper.getCommentByUid(uid);
    }

    @Override
    public int delComment(String uid) {
        return teachCommentMapper.delComment(uid);
    }

    @Override
    public int sendCommnet(TeachComment teachComment) {
        return teachCommentMapper.sendComment(teachComment);
    }
}
