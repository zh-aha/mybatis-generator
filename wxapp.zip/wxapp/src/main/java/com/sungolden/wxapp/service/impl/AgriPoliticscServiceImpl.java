package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.AgriPoliticsMapper;
import com.sungolden.wxapp.dto.AgriPolitics;
import com.sungolden.wxapp.service.AgriPoliticscService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgriPoliticscServiceImpl implements AgriPoliticscService {

    @Autowired
    private AgriPoliticsMapper agriPoliticsMapper;

    @Override
    public List<AgriPolitics> getPoliticsList() {
        return agriPoliticsMapper.getPoliticsList();
    }

    @Override
    public AgriPolitics getByUid(String uid) {
        return agriPoliticsMapper.getByUid(uid);
    }

    @Override
    public void updateCount(Integer count, String uid) {
        agriPoliticsMapper.updateCount(count, uid);
    }

    @Override
    public int postData(AgriPolitics agriPolitics) {
        return agriPoliticsMapper.postData(agriPolitics);
    }

    @Override
    public int update(AgriPolitics agriPolitics) {
        return agriPoliticsMapper.updateByPrimaryKeySelective(agriPolitics);
    }

    @Override
    public int delete(String[] uids) {
        return agriPoliticsMapper.delete(uids);
    }

    @Override
    public List<AgriPolitics> getIndexNews() {
        String[] uids = {"news1", "news2", "news3", "news4"};
        return agriPoliticsMapper.getIndexNews(uids);
    }

}
