package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.MachineComment;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MachineCommentMapper {
    int deleteByPrimaryKey(String uid);

    int insert(MachineComment record);

    int insertSelective(MachineComment record);

    MachineComment selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(MachineComment record);

    int updateByPrimaryKey(MachineComment record);

    //获取评论列表
    List<String> getCommentByUid(String uid);

    //评论
    int sendComment(MachineComment machineComment);

    //删除评论
    int delComment(String uid);
}