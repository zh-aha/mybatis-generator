package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author zh
 * @date 2019-11-14
 */
@Data
public class Phenological {
    /**
     * 编号
     */
    private String uid;

    /**
     * 作物类型
     */
    private String crop;

    /**
     * 物候期名称
     */
    private String pname;

    /**
     * 开始日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String start;

    /**
     * 结束日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String end;

    /**
     * 物候期图片
     */
    private String thumbnail;

    /**
     * 物候期描述
     */
    private String summary;

    //虫害、草害等等
    private List<EventType> eventTypes;

    private String cname;
}