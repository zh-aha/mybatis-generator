package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.TeachComment;

import java.util.List;

public interface TeacherCommentService {
    List<String> getCommentByUid(String uid);

    int delComment(String uid);

    int sendCommnet(TeachComment teachComment);
}
