package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.MachineComment;

import java.util.List;

public interface MachineCommentService {
    List<String> getCommentByUid(String uid);

    int sendCommemt(MachineComment machineComment);

    int delComment(String uid);
}
