package com.sungolden.wxapp.dto;

import lombok.Data;

import java.util.List;

/**
 * @author wcyong
 * @date 2019-12-23
 */
@Data
public class Township {
    private String code;

    private String name;

    private String pid;

    private List<Township> country;
}