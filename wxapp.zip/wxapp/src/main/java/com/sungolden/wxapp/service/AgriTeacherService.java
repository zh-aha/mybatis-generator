package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.AgriTeacher;

import java.util.List;

public interface AgriTeacherService {

    List<AgriTeacher> agriTeacherList();

    int sendInvitation(AgriTeacher agriTeacher);

    int delInvitation(String uid);

    AgriTeacher getByUid(String uid);
}
