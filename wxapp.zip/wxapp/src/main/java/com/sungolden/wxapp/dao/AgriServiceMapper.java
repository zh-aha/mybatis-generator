package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.AgriService;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgriServiceMapper {
    int deleteByPrimaryKey(String uid);

    int insert(AgriService record);

    int insertSelective(AgriService record);

    AgriService selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(AgriService record);

    int updateByPrimaryKey(AgriService record);

    //获取帖子列表
    List<AgriService> agriServiceList();

    //根据帖子id查看帖子详情
    AgriService getByUid(String uid);

    //发布帖子
    int sendInvitation(AgriService agriService);

    //删除帖子
    int delInvitation(String uid);
}