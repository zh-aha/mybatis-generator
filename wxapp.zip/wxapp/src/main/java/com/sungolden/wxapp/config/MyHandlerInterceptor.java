package com.sungolden.wxapp.config;

import com.sungolden.wxapp.service.RedisService;
import com.sungolden.wxapp.utils.*;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@Component
public class MyHandlerInterceptor implements HandlerInterceptor {

    @Autowired
    private RedisService redisService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //这里对请求参数进行拦截
        if (handler instanceof HandlerMethod) {
            Method authCheck = ((HandlerMethod) handler).getMethod();
            //如果被该AuthCheck注解 进入下面逻辑
            if (AnnotatedElementUtils.isAnnotated(authCheck, AuthCheck.class)) {
                AuthCheck annotation = (authCheck.getAnnotation(AuthCheck.class));
                if (annotation == null) {
                    return true;
                }
                //String m_token = request.getHeader("m_token");
                //Enumeration<String> m_token = request.getHeaders("m_token");
                //get request headers
                Enumeration headerNames = request.getHeaderNames();
                Map<String, String> map = new HashMap<String, String>();
                while (headerNames.hasMoreElements()) {
                    String key = (String) headerNames.nextElement();
                    String value = request.getHeader(key);
                    if (key.equals("m_token")) {
                        //管理端登录
                        if (!ToolUtils.isBlank(value)) {
                            String tokenRedis = (String) redisService.getObj(value);
                            if (!ToolUtils.isBlank(tokenRedis)) {
                                if (tokenRedis.equals(value)) {
                                    return true;
                                }
                                response.sendError(500, "登录失效");
                                return false;
                            }
                        }
                        response.sendError(500, "登录失效");
                        return false;
                    }
                }

                String token = request.getHeader("token");
                String decode_token = Base64Util.decode(token);
                //小程序登录
                if (!ToolUtils.isBlank(decode_token)) {
                    String tokenRedis = (String) redisService.getObj(decode_token);
                    if (!ToolUtils.isBlank(tokenRedis)) {
                        if (tokenRedis.equals(decode_token)) {
                            return true;
                        }
                        response.sendError(500, "登录失效");
                        return false;
                    }
                }
                response.sendError(500, "登录失效");
                return false;
            }
            return true;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
    }
}
