package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.Calamity;
import com.sungolden.wxapp.dto.EventType;
import com.sungolden.wxapp.service.CalamityService;
import com.sungolden.wxapp.service.EventTypeService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sun.dc.pr.PRError;

import java.util.List;

/**
 * @Description: 近期农事、虫害、草害等等
 * @Author: zh
 * @CreateDate: 2019/11/19 15:46
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/19 15:46
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/calamity")
public class CalamityController {

    @Autowired
    private CalamityService calamityService;

    /**
     * 获取某种灾害具体信息
     *
     * @param uid 灾害信息编号
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getByUid(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        Calamity byUid = calamityService.getByUid(uid);
        if (null == byUid) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        return DataReturnResult.success(byUid);
    }

    /**
     * list
     *
     * @return
     */
   // @AuthCheck
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public DataReturnResult list(Integer pageNum) {
        if (null == pageNum) {
            pageNum = 1;
        }
        if (pageNum < 0 || pageNum == 0) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<Calamity> list = calamityService.list();
        PageInfo<Calamity> pageInfo = new PageInfo<>(list);
        if (list.isEmpty()) {
            return DataReturnResult.success(pageInfo);
        }
        list.forEach(m -> {
            m.setName(m.getCname() + "-" + m.getPname() + "-" + m.getName());
        });
        return DataReturnResult.success(pageInfo);
    }

    /**
     * 添加
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public DataReturnResult post(@RequestBody Calamity calamity) {
        if (null == calamity) {
            return DataReturnResult.failure("0003", "数据不能为空");
        }
        if (ToolUtils.isBlank(calamity.getType())) {
            return DataReturnResult.failure("0003", "类型不能为空");
        }
        if (ToolUtils.isBlank(calamity.getTitle())) {
            return DataReturnResult.failure("0003", "标题不能为空");
        }
        if (ToolUtils.isBlank(calamity.getThumbnail())) {
            return DataReturnResult.failure("0003", "缩略图不能为空");
        }
        if (ToolUtils.isBlank(calamity.getContent())) {
            return DataReturnResult.failure("0003", "内容不能为空");
        }
        int i = calamityService.post(calamity);
        return DataReturnResult.success(i);
    }

    /**
     * 更新
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult update(@RequestBody Calamity calamity) {
        if (null == calamity) {
            return DataReturnResult.failure("0003", "数据不能为空");
        }
        if (ToolUtils.isBlank(calamity.getUid())) {
            return DataReturnResult.failure("0003", "编号不能为空");
        }
        if (ToolUtils.isBlank(calamity.getType())) {
            return DataReturnResult.failure("0003", "类型不能为空");
        }
        if (ToolUtils.isBlank(calamity.getTitle())) {
            return DataReturnResult.failure("0003", "标题不能为空");
        }
        if (ToolUtils.isBlank(calamity.getThumbnail())) {
            return DataReturnResult.failure("0003", "缩略图不能为空");
        }
        if (ToolUtils.isBlank(calamity.getContent())) {
            return DataReturnResult.failure("0003", "内容不能为空");
        }
        int i = calamityService.update(calamity);
        return DataReturnResult.success(i);
    }

    /**
     * 删除
     *
     * @param uids
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public DataReturnResult delete(String[] uids) {
        int i = calamityService.delete(uids);
        return DataReturnResult.success(i);
    }
}
