package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.EventType;
import com.sungolden.wxapp.dto.Phenological;
import com.sungolden.wxapp.service.CalamityService;
import com.sungolden.wxapp.service.EventTypeService;
import com.sungolden.wxapp.service.PhenologicalService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.HttpClientUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 物候期接口类信息
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/phenological")
public class PhenologicalController {

    @Autowired
    private PhenologicalService phenologicalService;

    @Autowired
    private EventTypeService eventTypeService;

    @Autowired
    private CalamityService calamityService;

    /**
     * 根据作物类型获取物候期信息
     *
     * @param crop
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getAll", method = RequestMethod.GET)
    public DataReturnResult getAll(String crop) {
        if (ToolUtils.isBlank(crop)) {
            List<Phenological> phenologicals = phenologicalService.getAll(crop);
            return DataReturnResult.success(phenologicals);
        }
        List<Phenological> phenologicals = phenologicalService.getAll(crop);
        return DataReturnResult.success(phenologicals);
    }

    /**
     * 获取物候期列表
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public DataReturnResult list(Integer pageNum) {
        if (null == pageNum) {
            pageNum = 1;
        }
        if (pageNum < 0 || pageNum == 0) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<Phenological> phenologicals = phenologicalService.list();
        PageInfo<Phenological> pageInfo = new PageInfo<>(phenologicals);
        return DataReturnResult.success(pageInfo);
    }

    /**
     * envent_type list
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/enventList", method = RequestMethod.GET)
    public DataReturnResult enventList() {
        List<EventType> eventTypes = phenologicalService.enventList();
        if (eventTypes.isEmpty()) {
            return DataReturnResult.success(eventTypes);
        }
        eventTypes.forEach(m -> {
            m.setName(m.getCname() + "--" + m.getPname() + "--" + m.getName());
        });
        return DataReturnResult.success(eventTypes);
    }

    /**
     * 根据物候期编号获取物候期信息
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getByUid(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        Phenological byUid = phenologicalService.getByUid(uid);
        if (null != byUid) {
            //某个物候期下的灾害类型
            List<EventType> nameList = eventTypeService.getNameList(byUid.getUid());
            //每个类型下的详细灾害信息
            nameList.forEach(n -> n.setCalamities(calamityService.getDetialByTypeId(n.getUid())));
            return DataReturnResult.success(nameList);
        }
        return DataReturnResult.failure("0003", "查询失败");
    }

    /**
     * 添加物候期信息
     *
     * @return
     */
    // @AuthCheck
    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public DataReturnResult post(@RequestBody Phenological phenological) {
        if (null == phenological) {
            return DataReturnResult.failure("0003", "数据不能为空");
        }
        if (ToolUtils.isBlank(phenological.getCrop())) {
            return DataReturnResult.failure("0003", "农作物编号不能为空");
        }
        if (ToolUtils.isBlank(phenological.getPname())) {
            return DataReturnResult.failure("0003", "物候期名称不能为空");
        }
        if (ToolUtils.isBlank(phenological.getStart())) {
            return DataReturnResult.failure("0003", "开始日期不能为空");
        }
        if (ToolUtils.isBlank(phenological.getEnd())) {
            return DataReturnResult.failure("0003", "结束日期不能为空");
        }
        if (ToolUtils.isBlank(phenological.getThumbnail())) {
            return DataReturnResult.failure("0003", "缩略图不能为空");
        }
        if (ToolUtils.isBlank(phenological.getSummary())) {
            return DataReturnResult.failure("0003", "简介不能为空");
        }
        int i = phenologicalService.insert(phenological);
        if (i == 1) {
            List<EventType> list = new ArrayList<>();
            EventType eventType = new EventType();
            eventType.setName("近期农事");
            eventType.setPId(phenological.getUid());
            list.add(eventType);
            EventType eventType1 = new EventType();
            eventType1.setName("近期易发病害");
            eventType1.setPId(phenological.getUid());
            list.add(eventType1);
            EventType eventType2 = new EventType();
            eventType2.setName("近期易发虫害");
            eventType2.setPId(phenological.getUid());
            list.add(eventType2);
            EventType eventType3 = new EventType();
            eventType3.setName("近期易发草害");
            eventType3.setPId(phenological.getUid());
            list.add(eventType3);
            int m = eventTypeService.insert(list);
            return DataReturnResult.success(i);
        }
        return DataReturnResult.success(i);
    }

    /**
     * 添加物候期信息
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult update(@RequestBody Phenological phenological) {
        if (null == phenological) {
            return DataReturnResult.failure("0003", "数据不能为空");
        }
        if (ToolUtils.isBlank(phenological.getUid())) {
            return DataReturnResult.failure("0003", "物候期编号不能为空");
        }
        if (ToolUtils.isBlank(phenological.getCrop())) {
            return DataReturnResult.failure("0003", "农作物编号不能为空");
        }
        if (ToolUtils.isBlank(phenological.getPname())) {
            return DataReturnResult.failure("0003", "物候期名称不能为空");
        }
        if (ToolUtils.isBlank(phenological.getStart())) {
            return DataReturnResult.failure("0003", "开始日期不能为空");
        }
        if (ToolUtils.isBlank(phenological.getEnd())) {
            return DataReturnResult.failure("0003", "结束日期不能为空");
        }
        if (ToolUtils.isBlank(phenological.getThumbnail())) {
            return DataReturnResult.failure("0003", "缩略图不能为空");
        }
        if (ToolUtils.isBlank(phenological.getSummary())) {
            return DataReturnResult.failure("0003", "简介不能为空");
        }
        int i = phenologicalService.update(phenological);
        return DataReturnResult.success(i);
    }

    /**
     * 删除
     *
     * @param uids
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public DataReturnResult delete(String[] uids) {
        if (null == uids) {
            return DataReturnResult.failure("0003", "请选择编号");
        }
        if (ToolUtils.isBlank(uids)) {
            return DataReturnResult.failure("0003", "请选择编号");
        }
        //先删除图片
        for (String uid :
                uids) {
            Phenological byUid = phenologicalService.getByUid(uid);
            String s = HttpClientUtil.doGet("http://192.168.2.77:8080/wxapp/del?filename=" + byUid.getThumbnail() + "&userId=1");
        }
        int i = phenologicalService.delete(uids);
        return DataReturnResult.success(i);
    }
}
