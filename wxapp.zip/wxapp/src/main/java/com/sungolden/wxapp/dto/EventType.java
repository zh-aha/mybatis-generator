package com.sungolden.wxapp.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zh
 * @date 2019-11-19
 */
@Data
public class EventType {
    private String uid;

    private String name;
    private String pId;
    private String pname;
    private String cname;

    private List<Calamity> calamities;
}