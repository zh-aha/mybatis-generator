package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.Calamity;

import java.util.List;

public interface CalamityService {

    Calamity getByUid(String uid);

    List<Calamity> getDetialByTypeId(String uid);

    int post(Calamity calamity);

    int update(Calamity calamity);

    int delete(String[] uids);

    List<Calamity> list();
}
