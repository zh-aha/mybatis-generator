package com.sungolden.wxapp.dto;

import lombok.Data;

/**
 * @author zh
 * @date 2019-12-09
 */
@Data
public class Role {
    private Integer id;

    /**
     * 角色编号
     */
    private Integer rid;

    /**
     * 角色名称
     */
    private String rname;

}