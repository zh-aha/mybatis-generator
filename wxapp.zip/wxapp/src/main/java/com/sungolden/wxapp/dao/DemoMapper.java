package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.Demo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DemoMapper {

    public List<Demo> demo();
}
