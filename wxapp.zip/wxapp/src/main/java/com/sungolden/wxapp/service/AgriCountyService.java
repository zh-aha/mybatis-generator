package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.AgriCounty;
import com.sungolden.wxapp.dto.Crop;

import java.util.List;

public interface AgriCountyService {

    AgriCounty countyData(String cid);

    List<AgriCounty> list(String cid);

    int post(AgriCounty agriCounty);

    int delete(String[] uids);

    int update(AgriCounty agriCounty);

    List<Crop> crops();

    Crop now();

    List<AgriCounty> mlist();
}
