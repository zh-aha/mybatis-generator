package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.GetYear;
import com.sungolden.wxapp.dto.Invitation;
import com.sungolden.wxapp.service.FavoriteService;
import com.sungolden.wxapp.service.InvitationService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/invitation")
public class InvitationController {

    @Autowired
    private InvitationService invitationService;
    @Autowired
    private FavoriteService favoriteService;
    @Autowired
    private UserInfoController userInfoController;

    /**
     * 普通农友圈 包含求助和普通农友圈 1普通圈子 2求助
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getInvitation", method = RequestMethod.GET)
    public DataReturnResult getInvitation(Integer userId) {
        if (null == userId) {
            List<Invitation> invitations = invitationService.getInvitation();
            invitations.forEach(n -> {
                n.setFavorite(false);
            });
            return DataReturnResult.success(invitations);
        }
        List<Invitation> invitations = invitationService.getInvitation();
        invitations.forEach(n -> {
            boolean isFavorite = favoriteService.isFavorite(n.getUid(), userId);
            n.setFavorite(isFavorite);
        });
        return DataReturnResult.success(invitations);
    }

    /**
     * 专家置顶帖子
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getExpert", method = RequestMethod.GET)
    public DataReturnResult getExpert(Integer userId) {
        if (null == userId) {
            List<Invitation> expertList = invitationService.getExpert();
            expertList.forEach(n -> {
                n.setFavorite(false);
            });
        }
        List<Invitation> expertList = invitationService.getExpert();
        expertList.forEach(n -> {
            boolean isFavorite = favoriteService.isFavorite(n.getUid(), userId);
            n.setFavorite(isFavorite);
        });
        return DataReturnResult.success(expertList);
    }

    /**
     * 获取某个帖子详情
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getByUid(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        Invitation byUid = invitationService.getByUid(uid);
        if (null == byUid) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        return DataReturnResult.success(byUid);
    }

    /**
     * 发帖接口
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/sendInvitation", method = RequestMethod.POST)
    public DataReturnResult sendInvitation(@RequestBody Invitation invitation) {
        //判断是农技专家或普通用户  role == 0 管理员 role ==1 农技专家 role ==2普通用户
        //type  类型0置顶，2提问，1农友圈
        if (!ToolUtils.isBlank(invitation.getRole()) && !ToolUtils.isBlank(invitation.getType()) && invitation.getRole() == 1 && invitation.getType() == 1) {
            //设置帖子类型为置顶
            invitation.setType(0);
        }
        if (ToolUtils.isBlank(invitation.getUserId())) {
            return DataReturnResult.failure("0003", "发帖失败输入用户id");
        }
        //此处前端需判断是否有内容，无内容提示用户输入，否则无法发送
        if (ToolUtils.isBlank(invitation.getType())) {
            return DataReturnResult.failure("0003", "请选择提问题/农友圈");
        }
        if (ToolUtils.isBlank(invitation.getContent())) {
            return DataReturnResult.failure("0003", "发布内容为空,请输入内容");
        }
        if (ToolUtils.isBlank(invitation.getRole())) {
            return DataReturnResult.failure("0003", "请选择角色");
        }
       /* if (!ToolUtils.isBlank(invitation.getAddress())) {
            if (ToolUtils.isBlank(invitation.getLocation())) {
                return DataReturnResult.failure("0003", "请选择位置");
            }
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String datetime = sdf.format(date);
        invitation.setUpdatetime(datetime);
        invitation.setIsDelete(false);
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(invitation.getContent());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = invitationService.sendInvitation(invitation);
                if (i == 0) {
                    return DataReturnResult.failure("0003", "发送失败");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "内容含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "发送失败");
        }
        return DataReturnResult.failure("0003", "发送失败");
    }

    /**
     * 删除帖子
     *
     * @param uid
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delInvitation", method = RequestMethod.DELETE)
    public DataReturnResult delInvitation(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "删除失败,无帖子id");
        }
        int i = invitationService.delInvitation(uid);
        if (i == 0) {
            return DataReturnResult.failure("0003", "删除失败,请重试");
        }
        return DataReturnResult.success(i);
    }

    /**
     * 我发布的圈子
     *
     * @param userId
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/myInvitation", method = RequestMethod.GET)
    public DataReturnResult myInvitation(Integer userId) {
        //获取年份
        List<GetYear> getYears = invitationService.getYear(userId);
        getYears.forEach(m -> m.setInvitations(invitationService.myInvitation(userId, m.getYears())));
        return DataReturnResult.success(getYears);
    }

}
