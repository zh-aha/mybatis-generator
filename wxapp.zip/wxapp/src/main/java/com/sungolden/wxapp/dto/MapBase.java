package com.sungolden.wxapp.dto;

import lombok.Data;

/**
 * 底图服务
 *
 * @author zh
 * @date 2019-11-27
 */
@Data
public class MapBase {
    /**
     * 编号
     */
    private String uid;

    /**
     * 服务名称
     */
    private String name;

    /**
     * 服务类型
     */
    private String type;

    /**
     * 访问地址
     */
    private String url;

    /**
     * 缩略图
     */
    private String thumb;

    /**
     * 序号
     */
    private Integer order;

}