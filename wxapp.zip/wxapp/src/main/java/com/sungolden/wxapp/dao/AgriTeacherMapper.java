package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.AgriTeacher;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgriTeacherMapper {

    List<AgriTeacher> agriTeacherList();

    int deleteByPrimaryKey(String uid);

    int insert(AgriTeacher record);

    int insertSelective(AgriTeacher record);

    AgriTeacher selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(AgriTeacher record);

    int updateByPrimaryKey(AgriTeacher record);

    //发送农师帖子
    int sendInvitation(AgriTeacher agriTeacher);

    int delInvitation(String uid);

    AgriTeacher getByUid(String uid);
}