package com.sungolden.wxapp.utils;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.PrecisionModel;
import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jts.io.WKBReader;
import com.vividsolutions.jts.io.WKTReader;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.Base64;

public class GeometryUtil {

    /*//获取Geometry
    public static Geometry getGeometryByBytes(byte[]  geometryAsBytes) throws Exception {
        Geometry geometry = null;
        // 字节数组小于5，说明geometry有问题
        if (geometryAsBytes.length < 5) {
            return null;
        }
        //这里是取字节数组的前4个来解析srid
        byte[] sridBytes = new byte[4];
        System.arraycopy(geometryAsBytes, 0, sridBytes, 0, 4);
        boolean bigEndian = (geometryAsBytes[4] == 0x00);
        // 解析srid
        int srid = 0;
        if (bigEndian) {
            for (int i = 0; i < sridBytes.length; i++) {
                srid = (srid << 8) + (sridBytes[i] & 0xff);
            }
        } else {
            for (int i = 0; i < sridBytes.length; i++) {
                srid += (sridBytes[i] & 0xff) << (8 * i);
            }
        }
        //use the JTS WKBReader for WKt parsing
        WKBReader wktReader = new WKBReader();
        // 使用geotool的WKBReader 把字节数组转成geometry对象。
        byte[] wkb = new byte[geometryAsBytes.length - 4];
        geometry = wktReader.read(wkb);
        geometry.setSRID(srid);
        return geometry;

    }
*/

    public static Geometry getGeometryFromInputStream(InputStream inputStream) throws Exception {

        Geometry dbGeometry = null;

        if (inputStream != null) {

            // 把二进制流转成字节数组
            //convert the stream to a byte[] array
            //so it can be passed to the WKBReader
            byte[] buffer = new byte[255];

            int bytesRead = 0;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }

            // 得到字节数组
            byte[] geometryAsBytes = baos.toByteArray();
            // 字节数组小于5，说明geometry有问题
            if (geometryAsBytes.length < 5) {
                throw new Exception("Invalid geometry inputStream - less than five bytes");
            }

            //first four bytes of the geometry are the SRID,
            //followed by the actual WKB.  Determine the SRID
            //这里是取字节数组的前4个来解析srid
            byte[] sridBytes = new byte[4];
            System.arraycopy(geometryAsBytes, 0, sridBytes, 0, 4);
            boolean bigEndian = (geometryAsBytes[4] == 0x00);
            // 解析srid
            int srid = 0;
            if (bigEndian) {
                for (int i = 0; i < sridBytes.length; i++) {
                    srid = (srid << 8) + (sridBytes[i] & 0xff);
                }
            } else {
                for (int i = 0; i < sridBytes.length; i++) {
                    srid += (sridBytes[i] & 0xff) << (8 * i);
                }
            }

            //use the JTS WKBReader for WKB parsing
            WKBReader wkbReader = new WKBReader();
            // 使用geotool的WKBReader 把字节数组转成geometry对象。
            //copy the byte array, removing the first four
            //SRID bytes
            byte[] wkb = new byte[geometryAsBytes.length - 4];
            System.arraycopy(geometryAsBytes, 4, wkb, 0, wkb.length);
            dbGeometry = wkbReader.read(wkb);
            dbGeometry.setSRID(srid);
        }

        return dbGeometry;

    }

    public static void main(String[] args) throws Exception {

        Class.forName("com.mysql.jdbc.Driver");
        // 获取连接
        Connection connection = DriverManager.getConnection("jdbc:mysql://192.168.2.77:3306/file_sever?useUnicode=true&characterEncoding=UTF-8&useSSL=true&autoReconnect=true",
                "root", "file");
        // 获取statement
        Statement statement = connection.createStatement();

        String sql = "select * from test";
        // 得到结果集
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()) {
            System.out.print(resultSet.getObject(1) + ",");
            System.out.print(resultSet.getObject(2) + ",");
            System.out.println();
            // 使用 getBinaryStream获取二进制流。
            InputStream inputStream = resultSet.getBinaryStream("location");
            // 转换为geometry对象
            Geometry geometry = getGeometryFromInputStream(inputStream);
            System.out.println(geometry.getInteriorPoint().toString());

        }

    }
}
