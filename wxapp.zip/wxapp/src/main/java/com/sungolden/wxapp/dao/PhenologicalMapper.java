package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.EventType;
import com.sungolden.wxapp.dto.Phenological;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PhenologicalMapper {
    int deleteByPrimaryKey(String uid);

    int insert(Phenological record);

    int insertSelective(Phenological record);

    Phenological selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(Phenological record);

    int updateByPrimaryKey(Phenological record);

    //根据作物类型获取相关物候期信息
    List<Phenological> getAll(String crop);

    //根据物候期编号获取物候期详情
    Phenological getByUid(String uid);

    List<Phenological> list();

    int delete(String[] uids);

    List<EventType> enventList();
}