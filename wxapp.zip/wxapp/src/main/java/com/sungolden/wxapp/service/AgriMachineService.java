package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.AgriMachine;

import java.util.List;

public interface AgriMachineService {
    List<AgriMachine> getMachine();

    AgriMachine getByUid(String uid);

    int delInvitation(String uid);

    int sendInvitation(AgriMachine agriMachine);
}
