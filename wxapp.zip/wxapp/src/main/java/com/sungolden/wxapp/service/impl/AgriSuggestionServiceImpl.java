package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.AgriSuggestionMapper;
import com.sungolden.wxapp.dto.AgriSuggestion;
import com.sungolden.wxapp.dto.Phenological;
import com.sungolden.wxapp.service.AgriSuggestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgriSuggestionServiceImpl implements AgriSuggestionService {

    @Autowired
    private AgriSuggestionMapper agriSuggestionMapper;

    @Override
    public AgriSuggestion getSuggestion(String cid, String pid) {
        return agriSuggestionMapper.getSuggestion(cid, pid);
    }

    @Override
    public int insert(AgriSuggestion suggestion) {
        return agriSuggestionMapper.insert(suggestion);
    }

    @Override
    public int delete(String[] uids) {
        return agriSuggestionMapper.delete(uids);
    }

    @Override
    public List<AgriSuggestion> list() {
        return agriSuggestionMapper.list();
    }

    @Override
    public int update(AgriSuggestion suggestion) {
        return agriSuggestionMapper.updateByPrimaryKeySelective(suggestion);
    }

    @Override
    public Phenological getPid(String cid) {
        return agriSuggestionMapper.getPid(cid);
    }
}
