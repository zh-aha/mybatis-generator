package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author zh
 * @date 2019-11-14
 */
@Data
public class AgriPolitics {
    /**
     * 编号
     */
    private String uid;

    /**
     * 发布人编号
     */
    private Integer userId;

    /**
     * 标题
     */
    private String title;

    /**
     * 缩略图
     */
    private String thumbnail;

    /**
     * 发布时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;

    /**
     * 阅读量
     */
    private Integer viewCount;

    /**
     * 文章内容，<p>text<p><img src=""/>
     */
    private String content;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    private boolean isFavorite;

    public boolean getIsFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean isFavorite) {
        this.isFavorite = isFavorite;
    }
}