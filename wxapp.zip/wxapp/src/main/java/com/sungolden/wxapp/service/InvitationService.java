package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.GetYear;
import com.sungolden.wxapp.dto.Invitation;

import java.util.List;

public interface InvitationService {
    List<Invitation> getInvitation();

    List<Invitation> getExpert();

    Invitation getByUid(String uid);

    int sendInvitation(Invitation invitation);

    int delInvitation(String uid);

    List<Invitation> myInvitation(Integer userId, String year);

    List<GetYear> getYear(Integer userId);
}
