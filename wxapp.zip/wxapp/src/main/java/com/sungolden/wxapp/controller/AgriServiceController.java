package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.AgriService;
import com.sungolden.wxapp.dto.User;
import com.sungolden.wxapp.service.AgriServices;
import com.sungolden.wxapp.service.FavoriteService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Description: 农服帖子信息
 * @Author: zh
 * @CreateDate: 2019/11/18 9:20
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/18 9:20
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/agri_service")
public class AgriServiceController {

    protected Logger log = LoggerFactory.getLogger(AgriServiceController.class);

    @Autowired
    private FavoriteService favoriteService;
    @Autowired
    private AgriServices agriServices;
    @Autowired
    private UserInfoController userInfoController;

    /**
     * @return
     * @throws Exception
     * @Description: 农服接口   获取所有农师发布的帖子信息  默认按时间排序
     */
    //@AuthCheck
    @RequestMapping(value = "/getInvitation", method = RequestMethod.GET)
    public DataReturnResult agriTeacherList(Integer userId) {
        log.info(">>>>>>>>>>>>>>>>>农服接口   获取所有农师发布的帖子信息  默认按时间排序>>>>>>>>>>>>>>");
        if (null == userId) {
            List<AgriService> agriServiceList = agriServices.agriServiceList();
            agriServiceList.forEach(n -> {
                n.setFavorite(false);
            });
            return DataReturnResult.success(agriServiceList);
        }
        List<AgriService> agriServiceList = agriServices.agriServiceList();
        agriServiceList.forEach(n -> {
            boolean favorite = favoriteService.isFavorite(n.getUid(), userId);
            n.setFavorite(favorite);
        });
        return DataReturnResult.success(agriServiceList);
    }

    /**
     * 获取某个帖子详情
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getInvitationByUid(String uid) {
        log.info(">>>>>>>>>>>>>>>>>农服接口   获取某个帖子详情 uid =" + uid + ">>>>>>>>>>>>>>");
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        AgriService byUid = agriServices.getByUid(uid);
        if (null == byUid) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        return DataReturnResult.success(byUid);
    }

    /**
     * 发农服帖接口
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/sendInvitation", method = RequestMethod.POST)
    public DataReturnResult sendInvitation(@RequestBody AgriService agriService) {
        log.info(">>>>>>>>>>>>>>>>>农服接口   发农服帖接口>>>>>>>>>>>>>>");
       /* if (ToolUtils.isBlank(agriService.getType())){
            agriService.setType("未认证");
        }*/
        if (ToolUtils.isBlank(agriService.getUserId())) {
            return DataReturnResult.failure("0003", "用户id为空");
        }
        //此处前端需判断是否有内容，无内容提示用户输入，否则无法发送
        if (ToolUtils.isBlank(agriService.getContent())) {
            return DataReturnResult.failure("0003", "发帖失败,无内容");
        }
       /* if (!ToolUtils.isBlank(agriService.getAddress())) {
            if (ToolUtils.isBlank(agriService.getLocation())) {
                return DataReturnResult.failure("0003", "请选择位置");
            }
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String datetime = sdf.format(date);
        agriService.setUpdatetime(datetime);
        agriService.setIsDelete(false);
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(agriService.getContent());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = agriServices.sendInvitation(agriService);
                if (i == 0) {
                    return DataReturnResult.failure("0003", "发送失败");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "内容含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "发送失败");
        }
        return DataReturnResult.failure("0003", "发送失败");
    }

    /**
     * 删除农服帖子
     *
     * @param uid
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delInvitation", method = RequestMethod.DELETE)
    public DataReturnResult delInvitation(String uid) {
        log.info(">>>>>>>>>>>>>>>>>农服接口   删除农服帖子 uid =" + uid + ">>>>>>>>>>>>>>");
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "删除失败,无帖子id");
        }
        int i = agriServices.delInvitation(uid);
        if (i == 0) {
            return DataReturnResult.failure("0003", "删除失败,请重试");
        }
        return DataReturnResult.success(i);
    }


}
