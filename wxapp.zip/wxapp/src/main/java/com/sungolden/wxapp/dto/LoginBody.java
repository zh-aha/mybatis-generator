package com.sungolden.wxapp.dto;

import lombok.Data;

@Data
public class LoginBody {
    private String password;

    private String account;
}
