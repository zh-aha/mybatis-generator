package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.ServiceComment;

import java.util.List;

public interface ServiceCommentService {
    List<String> getCommentByUid(String uid);

    int sendComment(ServiceComment serviceComment);

    int delComment(String uid);
}
