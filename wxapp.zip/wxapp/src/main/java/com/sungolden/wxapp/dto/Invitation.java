package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author zh
 * @date 2019-11-20
 */
@Data
public class Invitation {
    /**
     * 圈子编号
     */
    private String uid;

    /**
     * 用户编号
     */
    private Integer userId;

    /**
     * 类型1置顶，2提问，3农友圈
     */
    private Integer type;

    /**
     * 发布时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;

    /**
     * 文本内容
     */
    private String content;

    /**
     * 图片列表
     */
    private String picture;

    /**
     * 发布地址
     */
    private String address;

    /**
     * geometry经纬度点 4326坐标
     */
    private byte[] location;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    //新增属性
    private String wxNickName;

    private String wxIco;

    private Integer role;

    private String Ico;


    private String[] picturesUrl;

    private boolean isFavorite;

    public boolean getIsFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean isFavorite) {
        this.isFavorite = isFavorite;
    }
}