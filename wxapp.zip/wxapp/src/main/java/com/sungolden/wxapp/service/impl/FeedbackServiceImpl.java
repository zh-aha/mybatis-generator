package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.FeedbackMapper;
import com.sungolden.wxapp.dto.Feedback;
import com.sungolden.wxapp.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackMapper feedbackMapper;

    @Override
    public List<Feedback> getList() {
        return feedbackMapper.getList();
    }

    @Override
    public int insert(Feedback feedback) {
        return feedbackMapper.insert(feedback);
    }
}
