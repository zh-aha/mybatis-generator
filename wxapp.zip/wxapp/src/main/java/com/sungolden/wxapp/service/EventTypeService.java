package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.EventType;

import java.util.List;

public interface EventTypeService {
    List<EventType> getNameList(String type);

    int insert(List<EventType> list);
}
