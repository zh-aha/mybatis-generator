package com.sungolden.wxapp.dto;

import lombok.Data;

@Data
public class WeixinShare {

    private String nonceStr; //生成签名的随机串
    private long timestamp;  //生成签名的时间戳
    private String signature; //签名
    private String access_token;


}
