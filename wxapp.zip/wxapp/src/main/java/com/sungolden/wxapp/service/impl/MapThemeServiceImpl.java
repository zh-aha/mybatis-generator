package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.MapThemeMapper;
import com.sungolden.wxapp.dto.MapTheme;
import com.sungolden.wxapp.service.MapThemeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MapThemeServiceImpl implements MapThemeService {

    @Autowired
    private MapThemeMapper mapThemeMapper;

    @Override
    public MapTheme mapBaseDefault(String cid) {
        return mapThemeMapper.mapBaseDefault(cid);
    }

    @Override
    public int postData(MapTheme mapTheme) {
        return mapThemeMapper.postData(mapTheme);
    }

    @Override
    public int delete(String[] uids) {
        return mapThemeMapper.deleteByPrimaryKey(uids);
    }

    @Override
    public List<MapTheme> getThemeByType(String name, String date) {
        return mapThemeMapper.getThemeByType(name,date);
    }

    @Override
    public int update(MapTheme mapTheme) {
        return mapThemeMapper.updateByPrimaryKeySelective(mapTheme);
    }

    @Override
    public List<MapTheme> list() {
        return mapThemeMapper.themeList();
    }
}
