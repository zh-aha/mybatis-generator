package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.ServiceComment;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceCommentMapper {
    int deleteByPrimaryKey(String uid);

    int insert(ServiceComment record);

    int insertSelective(ServiceComment record);

    ServiceComment selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(ServiceComment record);

    int updateByPrimaryKey(ServiceComment record);

    //评论列表
    List<String> getCommentByUid(String uid);

    //评论
    int sendComment(ServiceComment serviceComment);

    //删除评论
    int delComment(String uid);
}