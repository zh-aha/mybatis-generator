package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.WeixinShare;
import com.sungolden.wxapp.utils.*;
import net.sf.json.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 分享功能
 * @Author: zh
 * @CreateDate: 2019/11/27 17:36
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/27 17:36
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/userInfo")
public class UserInfoController {

    // 微信appid
    //String appid = "xxx";
    // 微信secret
    //String secret = "xxx";
    // 初始化access_token
    String access_token = "";
    //  获取URL 这里的URL指的是需要分享的那个页面地址,建议这里不要写成固定地址，而是获取当前地址.
    String url = "url";
    @Autowired
    private SystemConfig systemConfig;

    /**
     * 微信分享功能获取凭证
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/share", method = RequestMethod.GET)
    public DataReturnResult share() {
        // 创建通过Api获取Token的链接与参数
        String requestTokenUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
       /* Map<String,String> requestUrlParam = new HashMap<>();
        requestUrlParam.put( "appid",systemConfig.appid);//小程序appId
        requestUrlParam.put( "secret",systemConfig.secret );*/
        requestTokenUrl = requestTokenUrl.replace("APPID", systemConfig.appid);
        requestTokenUrl = requestTokenUrl.replace("APPSECRET", systemConfig.secret);
        //JSONObject jsonObject1 = JSONObject.fromObject(requestTokenUrl);
        String s = HttpClientUtil.doGet(requestTokenUrl);
        JSONObject jsonObjectToken = JSONObject.fromObject(s);
        if (jsonObjectToken.has("access_token")) {
            //创建日期赋值为当前日期
            long createDate = new Date().getTime() / 1000;
            //获取token
            access_token = jsonObjectToken.getString("access_token");
            //获取token有效值
            long expires_in = jsonObjectToken.getLong("expires_in");
        }
       /*if (!ToolUtils.isBlank(jsonObjectToken)){
           //创建日期赋值为当前日期
           long createDate =new Date().getTime()/1000;
           //获取token
           access_token = jsonObjectToken.getString("access_token ");
           //获取token有效值
           long expires_in = jsonObjectToken.getLong("expires_in");
       }*/
        String requestUrl = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi";
        requestUrl = requestUrl.replace("ACCESS_TOKEN", access_token);
        //获取凭证
        String s1 = HttpClientUtil.doGet(requestUrl);
        JSONObject jsonObject = JSONObject.fromObject(s1);
        if (!ToolUtils.isBlank(jsonObject)) {
            try {
                String ticket = jsonObject.getString("ticket");
                String noncestr = RandomStrUtil.getRandomString(7);
                long timestamp = new Date().getTime() / 1000;

                String param = "jsapi_ticket=" + ticket + "&amp;noncestr=" + noncestr + "×tamp=" + timestamp + "&amp;url=" + url;
                String signature = DigestUtils.sha1Hex(param);
                WeixinShare weixinShare = new WeixinShare();
                weixinShare.setNonceStr(noncestr);
                weixinShare.setTimestamp(timestamp);
                weixinShare.setSignature(signature);
                weixinShare.setAccess_token(access_token);
                return DataReturnResult.success(weixinShare);
            } catch (Exception e) {
                e.printStackTrace();
                return DataReturnResult.failure("0003", "服务器异常");
            }
        }
        return DataReturnResult.failure("0003", "服务器异常");
    }

    /**
     * 敏感内容过滤
     *
     * @param content
     * @return
     */
    public Map<String, Object> getAccessToken(String content) {
        // 创建通过Api获取Token的链接与参数
        String requestTokenUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
       /* Map<String,String> requestUrlParam = new HashMap<>();
        requestUrlParam.put( "appid",systemConfig.appid);//小程序appId
        requestUrlParam.put( "secret",systemConfig.secret );*/
        requestTokenUrl = requestTokenUrl.replace("APPID", systemConfig.appid);
        requestTokenUrl = requestTokenUrl.replace("APPSECRET", systemConfig.secret);
        //JSONObject jsonObject1 = JSONObject.fromObject(requestTokenUrl);
        String s = HttpClientUtil.doGet(requestTokenUrl);
        JSONObject jsonObjectToken = JSONObject.fromObject(s);
        Map<String, String> map = new HashMap<>();
        if (jsonObjectToken.has("access_token")) {
            //创建日期赋值为当前日期
            long createDate = new Date().getTime() / 1000;
            //获取token
            String access_token = jsonObjectToken.getString("access_token");
            //获取token有效值
            long expires_in = jsonObjectToken.getLong("expires_in");
            //map.put("access_token",access_token);
            String url = "https://api.weixin.qq.com/wxa/msg_sec_check?access_token=" + access_token;
            JSONObject jsonObjects = new JSONObject();
            jsonObjects.put("content", content);
            String result = HttpClientUtil.post(jsonObjects, url);
            JSONObject jsonObject = JSONObject.fromObject(result);
            int errcode = jsonObject.getInt("errcode");
            String errMsg = jsonObject.getString("errmsg");
            Map<String, Object> maps = new HashMap<>();
            maps.put("errcode", errcode);
            map.put("errMsg", errMsg);
            return maps;
        }
        return null;
    }

    @RequestMapping(value = "checkPic", method = RequestMethod.POST)
    public DataReturnResult checkPicture(@RequestPart("imgs") MultipartFile imgs) {
        // 创建通过Api获取Token的链接与参数
        String requestTokenUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
        requestTokenUrl = requestTokenUrl.replace("APPID", systemConfig.appid);
        requestTokenUrl = requestTokenUrl.replace("APPSECRET", systemConfig.secret);
        //JSONObject jsonObject1 = JSONObject.fromObject(requestTokenUrl);
        String s = HttpClientUtil.doGet(requestTokenUrl);
        JSONObject jsonObjectToken = JSONObject.fromObject(s);
        Map<String, String> map = new HashMap<>();
        if (jsonObjectToken.has("access_token")) {
            //创建日期赋值为当前日期
            long createDate = new Date().getTime() / 1000;
            //获取token
            String access_token = jsonObjectToken.getString("access_token");
            //获取token有效值
            long expires_in = jsonObjectToken.getLong("expires_in");
            int errCode = checkPic(imgs, access_token, "form-data");
            Map<String, Object> res = new HashMap<>();
            if (errCode == 45002) {
                //图片过大
                res.put("error", 1);
            }
            if (errCode == 87014) {
                //图片违规
                res.put("error", 2);
            }
            if (errCode == 0) {
                res.put("ok", 3);
            }
            return DataReturnResult.success(res);
        }
        return null;
    }

    /**
     * 恶意图片过滤
     *
     * @param multipartFile
     * @return
     */
    private static int checkPic(MultipartFile multipartFile, String accessToken, String contentType) {
        try {

            CloseableHttpClient httpclient = HttpClients.createDefault();

            CloseableHttpResponse response = null;

            HttpPost request = new HttpPost("https://api.weixin.qq.com/wxa/img_sec_check?access_token=" + accessToken);
            request.addHeader("Content-Type", "application/octet-stream");

            InputStream inputStream = multipartFile.getInputStream();

            byte[] byt = new byte[inputStream.available()];
            inputStream.read(byt);
            request.setEntity(new ByteArrayEntity(byt, ContentType.create(contentType)));

            response = httpclient.execute(request);
            HttpEntity httpEntity = response.getEntity();
            String result = EntityUtils.toString(httpEntity, "utf-8");// 转成string

            JSONObject jso = JSONObject.fromObject(result);
            return getResult(jso);
        } catch (Exception e) {
            e.printStackTrace();
            return 1;
        }
    }

    private static int getResult(JSONObject jso) {
        Object errcode = jso.get("errcode");
        int errCode = (int) errcode;
        return errCode;
    }
}
