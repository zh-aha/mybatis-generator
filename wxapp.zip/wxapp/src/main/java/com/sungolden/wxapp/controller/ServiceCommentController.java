package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.ServiceComment;
import com.sungolden.wxapp.service.ServiceCommentService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Description: 农服评论接口类
 * @Author: zh
 * @CreateDate: 2019/11/18 11:28
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/18 11:28
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/service_comment")
public class ServiceCommentController {

    @Autowired
    private ServiceCommentService serviceCommentService;
    @Autowired
    private UserInfoController userInfoController;

    /**
     * 农服帖子评论列表
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getComment", method = RequestMethod.GET)
    public DataReturnResult getCommentByUid(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "uid不能为空");
        } else {
            List<String> commentList = serviceCommentService.getCommentByUid(uid);
            return DataReturnResult.success(commentList);
        }
    }

    /**
     * 评论
     *
     * @param serviceComment
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/sendComment", method = RequestMethod.POST)
    public DataReturnResult sendComment(@RequestBody ServiceComment serviceComment) {
        if (ToolUtils.isBlank(serviceComment.getUserId())) {
            return DataReturnResult.failure("0003", "发帖人id不能为空");
        }
        if (ToolUtils.isBlank(serviceComment.getInvitationId())) {
            return DataReturnResult.failure("0003", "评论帖子id不能为空");
        }
        if (ToolUtils.isBlank(serviceComment.getContent())) {
            return DataReturnResult.failure("0003", "评论内容不能为空");
        }
       /* if (ToolUtils.isBlank(serviceComment.getDestId())){
            return DataReturnResult.failure("0003","评论人id不能为空");
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String datetime = sdf.format(date);
        serviceComment.setUpdatetime(datetime);
        serviceComment.setIsDelete(false);
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(serviceComment.getContent());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = serviceCommentService.sendComment(serviceComment);
                if (i == 0) {
                    return DataReturnResult.failure("0000", "评论失败");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "内容含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "评论失败");
        }
        return DataReturnResult.failure("0003", "评论失败");
    }

    /**
     * 删除农服贴评论
     *
     * @param uid
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delComment", method = RequestMethod.DELETE)
    public DataReturnResult delComment(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "删除id为空");
        }
        int i = serviceCommentService.delComment(uid);
        if (i == 0) {
            return DataReturnResult.failure("0003", "删除失败,请重试");
        }
        return DataReturnResult.success(i);
    }

}
