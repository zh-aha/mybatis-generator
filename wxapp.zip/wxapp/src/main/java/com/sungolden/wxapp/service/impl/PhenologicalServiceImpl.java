package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.PhenologicalMapper;
import com.sungolden.wxapp.dto.EventType;
import com.sungolden.wxapp.dto.Phenological;
import com.sungolden.wxapp.service.PhenologicalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PhenologicalServiceImpl implements PhenologicalService {
    @Autowired
    private PhenologicalMapper phenologicalMapper;

    @Override
    public List<Phenological> getAll(String crop) {
        return phenologicalMapper.getAll(crop);
    }

    @Override
    public Phenological getByUid(String uid) {
        return phenologicalMapper.getByUid(uid);
    }

    @Override
    public int insert(Phenological phenological) {
        return phenologicalMapper.insert(phenological);
    }

    @Override
    public List<Phenological> list() {
        return phenologicalMapper.list();
    }

    @Override
    public int update(Phenological phenological) {
        return phenologicalMapper.updateByPrimaryKeySelective(phenological);
    }

    @Override
    public int delete(String[] uids) {
        return phenologicalMapper.delete(uids);
    }

    @Override
    public List<EventType> enventList() {
        return phenologicalMapper.enventList();
    }
}
