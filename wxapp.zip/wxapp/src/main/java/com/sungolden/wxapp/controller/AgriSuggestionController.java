package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.AgriSuggestion;
import com.sungolden.wxapp.dto.Phenological;
import com.sungolden.wxapp.service.AgriSuggestionService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.DateUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.crypto.Data;
import java.util.List;

/**
 * @Description: 管理建议
 * @Author: zh
 * @CreateDate: 2019/11/27 15:07
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/27 15:07
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/agri_suggestion")
public class AgriSuggestionController {

    @Autowired
    private AgriSuggestionService agriSuggestionService;

    /**
     * 默认展示某种农作物管理建议 单条数据
     *
     * @param cid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/default", method = RequestMethod.GET)
    public DataReturnResult getSuggestion(String cid) {
        //根据当前时间选择对应物候期
        Phenological phenological = agriSuggestionService.getPid(cid);
        if (null == phenological) {
            return DataReturnResult.failure("0003", "无数据");
        }
        AgriSuggestion agriSuggestion = agriSuggestionService.getSuggestion(cid, phenological.getUid());
        if (null == agriSuggestion) {
            return DataReturnResult.failure("0003", "无数据");
        }
        return DataReturnResult.success(agriSuggestion);
    }

    /**
     * 列表
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public DataReturnResult list(Integer pageNum) {
        if (ToolUtils.isBlank(pageNum)) {
            pageNum = 1;
        }
        //分页
        if (pageNum < 0 || pageNum == 1) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<AgriSuggestion> agriSuggestions = agriSuggestionService.list();
        PageInfo<AgriSuggestion> pageInfo = new PageInfo<>(agriSuggestions);
        return DataReturnResult.success(pageInfo);
    }

    /**
     * 发布管理建议
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public DataReturnResult insert(@RequestBody AgriSuggestion suggestion) {
        suggestion.setDate(DateUtil.getNow());
        int i = agriSuggestionService.insert(suggestion);
        return DataReturnResult.success(i);
    }

    /**
     * 修改管理建议
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult update(@RequestBody AgriSuggestion suggestion) {
        suggestion.setDate(DateUtil.getNow());
        int i = agriSuggestionService.update(suggestion);
        return DataReturnResult.success(i);
    }

    /**
     * 删除
     *
     * @param uids
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/del", method = RequestMethod.DELETE)
    public DataReturnResult delete(String[] uids) {
        if (ToolUtils.isBlank(uids)) {
            return DataReturnResult.failure("0003", "删除失败");
        }
        int i = agriSuggestionService.delete(uids);
        return DataReturnResult.success(i);
    }
}
