package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.AgriCounty;
import com.sungolden.wxapp.dto.Crop;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgriCountyMapper {
    int deleteByPrimaryKey(String uid);

    int insert(AgriCounty record);

    int insertSelective(AgriCounty record);

    AgriCounty selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(AgriCounty record);

    int updateByPrimaryKey(AgriCounty record);

    AgriCounty countyData(String cid);

    List<AgriCounty> list(String cid);

    int post(AgriCounty agriCounty);

    int delete(String[] uids);

    List<Crop> crops();

    Crop now();

    List<AgriCounty> mlist();
}