package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * 管理建议
 *
 * @author zh
 * @date 2019-11-27
 */
@Data
public class AgriSuggestion {
    /**
     * 编号
     */
    private String uid;

    /**
     * 管理建议
     */
    private String content;

    /**
     * 物候期编号
     */
    private String pId;

    /**
     * 数据日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String date;
    /**
     * 作物编号
     */
    private String cId;

    private String cname;
    private String pname;

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }
}