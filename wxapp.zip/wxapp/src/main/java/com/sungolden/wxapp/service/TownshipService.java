package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.Township;

import java.util.List;

public interface TownshipService {
    List<Township> getCity();

    List<Township> getContry(String code);
}
