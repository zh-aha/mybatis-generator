package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

@Service
public class RedisServiceImpl implements RedisService {
    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public void setObj(String key, Object obj, long timeout) {
        ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
        operations.set(key, obj, timeout, TimeUnit.SECONDS);
    }

    @Override
    public Object getObj(String key) {
        Object o = redisTemplate.opsForValue().get(key);
        return o;
    }

    @Override
    public void delObj(String key) {

        Boolean delete = redisTemplate.delete(key);
    }

    @Override
    public HashMap<Object, Object> getRedis() {
        //获取所有的key
        redisTemplate.keys("*");
        return null;
    }
}
