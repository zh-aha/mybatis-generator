package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.AgriSuggestion;
import com.sungolden.wxapp.dto.Phenological;

import java.util.List;

public interface AgriSuggestionService {
    AgriSuggestion getSuggestion(String cid, String pid);

    int insert(AgriSuggestion suggestion);

    int delete(String[] uids);

    List<AgriSuggestion> list();

    int update(AgriSuggestion suggestion);

    Phenological getPid(String cid);
}
