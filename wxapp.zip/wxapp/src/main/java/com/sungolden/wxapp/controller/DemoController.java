package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.dto.Demo;
import com.sungolden.wxapp.service.DemoService;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/demo")
public class DemoController {
    protected Logger log = LoggerFactory.getLogger(DemoController.class);
    @Autowired
    private DemoService demoService;

    // @AuthCheck(intVal = 2,stringVal = "token")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public List<Demo> demo() {

        return demoService.demo();
    }

}
