package com.sungolden.wxapp.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.vividsolutions.jts.geom.Geometry;
import lombok.Data;
import org.joda.time.DateTime;

import java.util.Date;

/**
 * @author zh
 * @date 2019-11-14
 */
@Data
public class AgriTeacher {
    /**
     * 编号
     */
    private String uid;

    /**
     * 用户编号
     */
    private Integer userId;

    /**
     * 类型1认证
     */
    private String type;

    /**
     * 发布时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private String updatetime;

    /**
     * 文本内容
     */
    private String content;

    /**
     * 图片地址
     */
    private String pictures;

    /**
     * 发布地址
     */
    private String address;

    /**
     * 经纬度点 4326坐标
     */
    private byte[] location;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    //新增属性用户姓名
    private String wxNickName;

    //新增属性用户头像
    private String wxIco;
    private String Ico;
    /**
     * 经纬度点 4326坐标
     */
    private Geometry geometry;


    private String[] picturesUrl;

    private boolean isFavorite;

    public boolean getIsFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean isFavorite) {
        this.isFavorite = isFavorite;
    }
}