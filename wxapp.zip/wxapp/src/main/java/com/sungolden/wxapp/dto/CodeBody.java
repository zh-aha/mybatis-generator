package com.sungolden.wxapp.dto;

import lombok.Data;

@Data
public class CodeBody {
    private String code;

    private String rawData;
}
