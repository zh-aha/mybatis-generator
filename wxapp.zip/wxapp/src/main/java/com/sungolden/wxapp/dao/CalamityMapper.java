package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.Calamity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CalamityMapper {
    int deleteByPrimaryKey(String uid);

    int insert(Calamity record);

    int insertSelective(Calamity record);

    Calamity selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(Calamity record);

    int updateByPrimaryKey(Calamity record);

    Calamity getByUid(String uid);

    List<Calamity> getDetialByTypeId(String uid);

    int delete(String[] uids);

    List<Calamity> list();
}