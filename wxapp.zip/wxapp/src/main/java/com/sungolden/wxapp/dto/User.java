package com.sungolden.wxapp.dto;

import lombok.Data;

/**
 * @author zh
 * @date 2019-11-13
 */
@Data
public class User {
    /**
     * 用户编号
     */
    private Integer id;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 姓名
     */
    private String name;

    /**
     * 性别
     */
    private Integer sex;

    /**
     * 密码
     */
    private String password;

    /**
     * 角色
     */
    private Integer role;

    /**
     * 头像
     */
    private String ico;

    /**
     * 微信id
     */
    private String wxUid;

    /**
     * 微信头像
     */
    private String wxIco;

    /**
     * 微信昵称
     */
    private String wxNickname;

    /**
     * 微信地址
     */
    private String wxAddress;
    //新增字段
    private String message;

    private int flag;
    //角色名称
    private String rname;

}