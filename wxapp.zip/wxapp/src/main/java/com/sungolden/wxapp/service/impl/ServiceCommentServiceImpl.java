package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.ServiceCommentMapper;
import com.sungolden.wxapp.dto.ServiceComment;
import com.sungolden.wxapp.service.ServiceCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceCommentServiceImpl implements ServiceCommentService {

    @Autowired
    private ServiceCommentMapper serviceCommentMapper;

    @Override
    public List<String> getCommentByUid(String uid) {
        return serviceCommentMapper.getCommentByUid(uid);
    }

    @Override
    public int sendComment(ServiceComment serviceComment) {
        return serviceCommentMapper.sendComment(serviceComment);
    }

    @Override
    public int delComment(String uid) {
        return serviceCommentMapper.delComment(uid);
    }
}
