package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.AgriTeacher;
import com.sungolden.wxapp.service.AgriTeacherService;
import com.sungolden.wxapp.service.FavoriteService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.DateUtils;
import com.sungolden.wxapp.utils.ToolUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Description: java类作用描述
 * @Author: zh
 * @CreateDate: 2019/11/14 15:03
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/14 15:03
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/agri_teacher")
public class AgriTeacherController {

    protected Logger log = LoggerFactory.getLogger(AgriTeacherController.class);

    @Autowired
    private FavoriteService favoriteService;
    @Autowired
    private AgriTeacherService agriTeacherService;
    @Autowired
    private UserInfoController userInfoController;

    /**
     * @return
     * @throws Exception
     * @Description: 农师接口   获取所有农师发布的帖子信息  默认按时间排序
     */
    //@AuthCheck
    @RequestMapping(value = "/getInvitation", method = RequestMethod.GET)
    public DataReturnResult agriTeacherList(Integer userId) {
        log.info(">>>>>>>>>>>>>>>>>农师接口   获取所有农师发布的帖子信息>>>>>>>>>>>>>>");
        if (null == userId) {
            List<AgriTeacher> agriTeachers = agriTeacherService.agriTeacherList();
            agriTeachers.forEach(n -> {
                n.setFavorite(false);
            });
            return DataReturnResult.success(agriTeachers);
        }
        List<AgriTeacher> agriTeachers = agriTeacherService.agriTeacherList();
        agriTeachers.forEach(n -> {
            boolean favorite = favoriteService.isFavorite(n.getUid(), userId);
            n.setFavorite(favorite);
        });
        return DataReturnResult.success(agriTeachers);
    }

    /**
     * 获取某个帖子详情
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getInvitationByUid(String uid) {
        log.info(">>>>>>>>>>>>>>>>>农师接口   获取某个帖子详情 uid = " + uid + ">>>>>>>>>>>>>>");
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        AgriTeacher byUid = agriTeacherService.getByUid(uid);
        if (null == byUid) {
            return DataReturnResult.failure("0003", "获取内容失败");
        }
        return DataReturnResult.success(byUid);
    }

    /**
     * 发农师帖接口
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/sendInvitation", method = RequestMethod.POST)
    public DataReturnResult sendInvitation(@RequestBody AgriTeacher agriTeacher) {
        log.info(">>>>>>>>>>>>>>>>>农师接口   发农师帖接口");
        agriTeacher.setType("认证");
        if (ToolUtils.isBlank(agriTeacher.getUserId())) {
            return DataReturnResult.failure("0003", "用户id为空");
        }
        //此处前端需判断是否有内容，无内容提示用户输入，否则无法发送
        if (ToolUtils.isBlank(agriTeacher.getContent())) {
            return DataReturnResult.failure("0003", "发帖失败,无内容");
        }
        /*if (!ToolUtils.isBlank(agriTeacher.getAddress())) {
            if (ToolUtils.isBlank(agriTeacher.getLocation())) {
                return DataReturnResult.failure("0003", "请选择位置");
            }
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String datetime = sdf.format(date);
        agriTeacher.setUpdatetime(datetime);
        agriTeacher.setIsDelete(false);
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(agriTeacher.getContent());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = agriTeacherService.sendInvitation(agriTeacher);
                if (i == 0) {
                    return DataReturnResult.failure("0003", "发送失败");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "内容含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "发送失败");
        }
        return DataReturnResult.failure("0003", "发送失败");
    }

    /**
     * 删除农师帖子
     *
     * @param uid
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delInvitation", method = RequestMethod.DELETE)
    public DataReturnResult delInvitation(String uid) {
        log.info(">>>>>>>>>>>>>>>>>农师接口   删除农师帖子 uid=" + uid + ">>>>>>>>>>>>");
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "删除失败,无帖子id");
        }
        int i = agriTeacherService.delInvitation(uid);
        if (i == 0) {
            return DataReturnResult.failure("0003", "删除失败,请重试");
        }
        return DataReturnResult.success(i);
    }
}
