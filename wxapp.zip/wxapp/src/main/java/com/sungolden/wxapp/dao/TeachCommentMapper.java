package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.TeachComment;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeachCommentMapper {
    int deleteByPrimaryKey(String uid);

    int insert(TeachComment record);

    int insertSelective(TeachComment record);

    TeachComment selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(TeachComment record);

    int updateByPrimaryKey(TeachComment record);

    //根据帖子id获取评论列表
    List<String> getCommentByUid(String uid);

    //删除评论
    int delComment(String uid);

    //评论
    int sendComment(TeachComment teachComment);
}