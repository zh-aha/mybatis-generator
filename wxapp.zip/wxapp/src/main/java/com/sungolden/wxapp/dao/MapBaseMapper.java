package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.MapBase;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MapBaseMapper {
    int deleteByPrimaryKey(String[] uids);

    int insert(MapBase record);

    int insertSelective(MapBase record);

    MapBase selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(MapBase record);

    int updateByPrimaryKey(MapBase record);

    //默认底图
    MapBase mapBaseDefault();

    //切换底图
    MapBase nextMap(Integer order);

    //发布底图服务数据
    int postData(MapBase mapBase);

    //获取最小序号
    Integer getOrderMin();

    //所有底图
    List<MapBase> maps();

}