package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.EventTypeMapper;
import com.sungolden.wxapp.dto.EventType;
import com.sungolden.wxapp.service.EventTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventTypeServiceImpl implements EventTypeService {

    @Autowired
    private EventTypeMapper eventTypeMapper;

    @Override
    public List<EventType> getNameList(String type) {
        return eventTypeMapper.getNameList(type);
    }

    @Override
    public int insert(List<EventType> list) {
        return eventTypeMapper.insert(list);
    }
}
