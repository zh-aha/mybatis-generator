package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.CalamityMapper;
import com.sungolden.wxapp.dto.Calamity;
import com.sungolden.wxapp.service.CalamityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalamityServiceImpl implements CalamityService {

    @Autowired
    private CalamityMapper calamityMapper;

    @Override
    public Calamity getByUid(String uid) {
        return calamityMapper.getByUid(uid);
    }

    @Override
    public List<Calamity> getDetialByTypeId(String uid) {
        return calamityMapper.getDetialByTypeId(uid);
    }

    @Override
    public int post(Calamity calamity) {
        return calamityMapper.insert(calamity);
    }

    @Override
    public int update(Calamity calamity) {
        return calamityMapper.updateByPrimaryKeySelective(calamity);
    }

    @Override
    public int delete(String[] uids) {
        return calamityMapper.delete(uids);
    }

    @Override
    public List<Calamity> list() {
        return calamityMapper.list();
    }
}
