package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.Feedback;
import com.sungolden.wxapp.service.FeedbackService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.DateUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.crypto.Data;
import java.util.List;

/**
 * @Description: 意见反馈
 * @Author: zh
 * @CreateDate: 2019/11/27 17:45
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/27 17:45
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    /**
     * 获取反馈意见表
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public DataReturnResult getList() {
        List<Feedback> feedbacks = feedbackService.getList();
        return DataReturnResult.success(feedbacks);
    }

    /**
     * 反馈意见
     *
     * @param feedback
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public DataReturnResult insert(@RequestBody Feedback feedback) {
        if (ToolUtils.isBlank(feedback.getUserId())) {
            return DataReturnResult.failure("0003", "用户id为空");
        }
        if (ToolUtils.isBlank(feedback.getContent())) {
            return DataReturnResult.failure("0003", "内容不能为空");
        }
        feedback.setUpdatetime(DateUtil.getNow());
        int i = feedbackService.insert(feedback);
        if (i == 0) {
            return DataReturnResult.failure("0003", "发表失败");
        }
        return DataReturnResult.success(i);
    }

}
