package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.MapTheme;

import java.util.List;

public interface MapThemeService {
    MapTheme mapBaseDefault(String cid);

    int postData(MapTheme mapTheme);

    int delete(String[] uid);

    List<MapTheme> getThemeByType(String name, String date);

    int update(MapTheme mapTheme);

    List<MapTheme> list();
}
