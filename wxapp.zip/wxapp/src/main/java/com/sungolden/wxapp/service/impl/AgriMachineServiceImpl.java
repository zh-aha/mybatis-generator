package com.sungolden.wxapp.service.impl;

import com.sungolden.wxapp.dao.AgriMachineMapper;
import com.sungolden.wxapp.dto.AgriMachine;
import com.sungolden.wxapp.service.AgriMachineService;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgriMachineServiceImpl implements AgriMachineService {

    @Autowired
    private AgriMachineMapper agriMachineMapper;

    @Override
    public List<AgriMachine> getMachine() {
        List<AgriMachine> machine = agriMachineMapper.getMachine();
        machine.forEach(m -> {
            if (!ToolUtils.isBlank(m.getPictures())) {
                m.setPicturesUrl(m.getPictures().split(","));
            }
        });
        return machine;
    }

    @Override
    public AgriMachine getByUid(String uid) {
        AgriMachine byUid = agriMachineMapper.getByUid(uid);
        if (null != byUid && null != byUid.getPictures()) {
            byUid.setPicturesUrl(byUid.getPictures().split(","));
        }
        return byUid;
    }

    @Override
    public int delInvitation(String uid) {
        return agriMachineMapper.delInvitation(uid);
    }

    @Override
    public int sendInvitation(AgriMachine agriMachine) {
        return agriMachineMapper.sendInvitation(agriMachine);
    }
}
