package com.sungolden.wxapp.service;

import com.sungolden.wxapp.dto.AgriService;

import java.util.List;

public interface AgriServices {
    List<AgriService> agriServiceList();

    AgriService getByUid(String uid);

    int sendInvitation(AgriService agriService);

    int delInvitation(String uid);
}
