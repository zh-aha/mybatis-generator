package com.sungolden.wxapp.dao;

import com.sungolden.wxapp.dto.MapTheme;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MapThemeMapper {
    int deleteByPrimaryKey(String[] uids);

    int insert(MapTheme record);

    int insertSelective(MapTheme record);

    MapTheme selectByPrimaryKey(String uid);

    int updateByPrimaryKeySelective(MapTheme record);

    int updateByPrimaryKey(MapTheme record);

    MapTheme mapBaseDefault(String cid);

    int postData(MapTheme mapTheme);

    List<MapTheme> getThemeByType(@Param("name") String name, @Param("date") String date);

    List<MapTheme> themeList();
}