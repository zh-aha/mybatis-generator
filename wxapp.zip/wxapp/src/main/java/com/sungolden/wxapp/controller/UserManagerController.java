package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.MapBase;
import com.sungolden.wxapp.dto.User;
import com.sungolden.wxapp.service.UserService;
import com.sungolden.wxapp.utils.Base64Util;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.crypto.Data;
import java.util.List;

/**
 * @Description: 后台管理
 * @Author: zh
 * @CreateDate: 2019/11/22 14:53
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/22 14:53
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/user_manager")
public class UserManagerController {

    @Autowired
    private UserService userService;

    /**
     * 获取用户信息
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public DataReturnResult getUsers(Integer pageNum) {
        //分页
        if (ToolUtils.isBlank(pageNum)) {
            pageNum = 1;
        }
        if (pageNum < 0 || pageNum == 0) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<User> users = userService.users();
        users.forEach(m -> m.setMessage(null));
        PageInfo<MapBase> pageInfo = new PageInfo(users);
        return DataReturnResult.success(pageInfo);
    }

    /**
     * 删除
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/del", method = RequestMethod.DELETE)
    public DataReturnResult delete(Integer[] ids) {
        if (ToolUtils.isBlank(ids)) {
            return DataReturnResult.failure("0003", "id不能为空");
        }
        int i = userService.delete(ids);
        return DataReturnResult.success(i);
    }

    /**
     * 管理员修改用户信息
     *
     * @param user
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult updateInfo(@RequestBody User user) {
        if (null != user) {
            if (ToolUtils.isBlank(user.getId())) {
                return DataReturnResult.failure("0003", "修改失败");
            }
            if (ToolUtils.isBlank(user.getIco())) {
                return DataReturnResult.failure("0003", "头像不能为空");
            }
            if (ToolUtils.isBlank(user.getName())) {
                return DataReturnResult.failure("0003", "姓名不能为空");
            }
            if (ToolUtils.isBlank(user.getRole())) {
                return DataReturnResult.failure("0003", "角色id不能为空");
            }
            if (ToolUtils.isBlank(user.getWxAddress())) {
                return DataReturnResult.failure("0003", "地址不能为空");
            }
            if (ToolUtils.isBlank(user.getWxNickname())) {
                return DataReturnResult.failure("0003", "昵称不能为空");
            }
            if (ToolUtils.isBlank(user.getWxUid())) {
                return DataReturnResult.failure("0003", "帐号不能为空");
            }
            if (ToolUtils.isBlank(user.getPassword())) {
                return DataReturnResult.failure("0003", "密码不能为空");
            }
            String account = Base64Util.encode(user.getWxUid());
            String pwd1 = Base64Util.encode(user.getPassword());
            String pwd = Base64Util.encode(pwd1);
            User account1 = userService.findAccount(account);
            if (account1 != null) {
                return DataReturnResult.failure("0004", "用户名已存在");
            }
            user.setWxUid(account);
            user.setPassword(pwd);
            int i = userService.updateInfo(user);
            return DataReturnResult.success(i);
        }
        return DataReturnResult.failure("0003", "修改失败");
    }

    /**
     * 添加用户
     *
     * @param user
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public DataReturnResult add(@RequestBody User user) {
        if (null != user) {
            if (ToolUtils.isBlank(user.getIco())) {
                return DataReturnResult.failure("0003", "头像不能为空");
            }
            if (ToolUtils.isBlank(user.getSex())) {
                return DataReturnResult.failure("0003", "性别不能为空");
            }
            if (ToolUtils.isBlank(user.getName())) {
                return DataReturnResult.failure("0003", "姓名不能为空");
            }
            if (ToolUtils.isBlank(user.getWxAddress())) {
                return DataReturnResult.failure("0003", "地址不能为空");
            }
            if (ToolUtils.isBlank(user.getWxNickname())) {
                return DataReturnResult.failure("0003", "昵称不能为空");
            }
            if (ToolUtils.isBlank(user.getWxUid())) {
                return DataReturnResult.failure("0003", "帐号不能为空");
            }
            if (ToolUtils.isBlank(user.getPassword())) {
                return DataReturnResult.failure("0003", "密码不能为空");
            }
            String account = Base64Util.encode(user.getWxUid());
            String pwd1 = Base64Util.encode(user.getPassword());
            String pwd = Base64Util.encode(pwd1);
            User account1 = userService.findAccount(account);
            if (account1 != null) {
                return DataReturnResult.failure("0004", "用户名已存在");
            }
            user.setWxUid(account);
            user.setPassword(pwd);
            int insert = userService.insert(user);
            return DataReturnResult.success(insert);
        }
        return DataReturnResult.failure("0003", "添加失败");
    }

    /**
     * 权限赋予
     *
     * @param user
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/grant", method = RequestMethod.PUT)
    public DataReturnResult grant(@RequestBody User user, @RequestBody User user1) {
        if (null == user) {
            return DataReturnResult.failure("0003", "信息不完整");
        }
        if (ToolUtils.isBlank(user.getRole())) {
            return DataReturnResult.failure("0003", "角色信息错误");
        }
        if (user.getRole() == -1) {
            //超级管理员权限

        }
        if (user.getRole() == 0) {
            //管理员权限
        }
        return DataReturnResult.failure("0003", "权限分配失败");
    }
}
