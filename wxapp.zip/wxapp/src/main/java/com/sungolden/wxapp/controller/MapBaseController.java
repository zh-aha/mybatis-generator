package com.sungolden.wxapp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sun.org.apache.regexp.internal.REDebugCompiler;
import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.MapBase;
import com.sungolden.wxapp.service.MapBaseService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.HttpClientUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Description: 底图服务
 * @Author: zh
 * @CreateDate: 2019/11/27 14:47
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/27 14:47
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/app/map_base")
public class MapBaseController {

    @Autowired
    private MapBaseService mapBaseService;

    /**
     * 默认显示的底图
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/default", method = RequestMethod.GET)
    public DataReturnResult mapBaseDefault() {
        MapBase mapBase = mapBaseService.mapBaseDefault();
        if (null == mapBase) {
            return DataReturnResult.failure("0003", "无数据");
        }
        return DataReturnResult.success(mapBase);
    }

    /**
     * 所有的底图
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/maps", method = RequestMethod.GET)
    public DataReturnResult maps(Integer pageNum) {
        if (ToolUtils.isBlank(pageNum)) {
            pageNum = 1;
        }
        //分页
        if (pageNum < 0 || pageNum == 0) {
            pageNum = 1;
        }
        PageHelper.startPage(pageNum, 10);
        List<MapBase> maps = mapBaseService.maps();
        PageInfo<MapBase> pageInfo = new PageInfo(maps);
        return DataReturnResult.success(pageInfo);
    }

    /**
     * 切换底图
     *
     * @param order 当前底图的order
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/nextMap", method = RequestMethod.GET)
    public DataReturnResult getNextMap(Integer order) {
        if (ToolUtils.isBlank(order)) {
            return DataReturnResult.failure("0003", "参数不能为空");
        }
        Integer minOrder = mapBaseService.getOrderMin();
        if (ToolUtils.isBlank(minOrder)) {
            return DataReturnResult.failure("0003", "无数据");
        }
        //此序号为最后一个 返回默认数据 默认值为最大序号对应的数据
        if (order == minOrder) {
            MapBase mapBase = mapBaseService.mapBaseDefault();
            return DataReturnResult.success(mapBase);
        }
        //此序号不是最小序号
        if (order > minOrder) {
            //未查到数据 递归查询到数据为止
            Integer newOrder = order - 1;
            MapBase mapBase = mapBaseService.nextMap(order - 1);
            if (null == mapBase) {
                getNextMap(newOrder);
            }
            return DataReturnResult.success(mapBase);
        }
        return DataReturnResult.failure("0003", "查询失败");
    }

    /**
     * 发布数据
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public DataReturnResult postData(@RequestBody MapBase mapBase) {
        if (null != mapBase) {
            if (ToolUtils.isBlank(mapBase.getName())) {
                return DataReturnResult.failure("0003", "服务名称不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getType())) {
                return DataReturnResult.failure("0003", "服务类型不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getUrl())) {
                return DataReturnResult.failure("0003", "访问地址不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getUrl())) {
                return DataReturnResult.failure("0003", "缩略图不能为空");
            }
            int i = mapBaseService.postData(mapBase);
            if (i == 1) {
                return DataReturnResult.success(i);
            }
            return DataReturnResult.failure("0003", "发布失败");
        }
        return DataReturnResult.failure("0003", "发布失败");
    }

    /**
     * 发布数据
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult update(@RequestBody MapBase mapBase) {
        if (null != mapBase) {
            if (ToolUtils.isBlank(mapBase.getUid())) {
                return DataReturnResult.failure("0003", "编号不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getName())) {
                return DataReturnResult.failure("0003", "服务名称不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getType())) {
                return DataReturnResult.failure("0003", "服务类型不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getUrl())) {
                return DataReturnResult.failure("0003", "访问地址不能为空");
            }
            if (ToolUtils.isBlank(mapBase.getUrl())) {
                return DataReturnResult.failure("0003", "缩略图不能为空");
            }
            int i = mapBaseService.update(mapBase);
            if (i == 1) {
                return DataReturnResult.success(i);
            }
            return DataReturnResult.failure("0003", "修改失败");
        }
        return DataReturnResult.failure("0003", "修改失败");
    }

    /**
     * 删除
     *
     * @param uids
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public DataReturnResult delete(String[] uids) {
        int i = mapBaseService.delete(uids);
        return DataReturnResult.success(i);
    }

    /**
     * 获取天气数据
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getWeather", method = RequestMethod.GET)
    public DataReturnResult getWeather() {
        String s = HttpClientUtil.doGet("http://t.weather.sojson.com/api/weather/city/101090808");
        return DataReturnResult.success(s);
    }
}
