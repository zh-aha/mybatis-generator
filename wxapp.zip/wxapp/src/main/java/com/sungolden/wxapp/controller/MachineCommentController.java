package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.MachineComment;
import com.sungolden.wxapp.service.MachineCommentService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Description: 农机帖子评论
 * @Author: zh
 * @CreateDate: 2019/11/15 17:51
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/15 17:51
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/machine_comment")
public class MachineCommentController {

    @Autowired
    private MachineCommentService machineCommentService;

    @Autowired
    private UserInfoController userInfoController;

    /**
     * 农机帖子评论列表
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getComment", method = RequestMethod.GET)
    public DataReturnResult getCommentByUid(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "uid不能为空");
        } else {
            List<String> commentList = machineCommentService.getCommentByUid(uid);
            return DataReturnResult.success(commentList);
        }
    }

    /**
     * 评论
     *
     * @param machineComment
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/sendComment", method = RequestMethod.POST)
    public DataReturnResult sendComment(@RequestBody MachineComment machineComment) {
        if (ToolUtils.isBlank(machineComment.getUserId())) {
            return DataReturnResult.failure("0003", "发帖人id不能为空");
        }
        if (ToolUtils.isBlank(machineComment.getInvitationId())) {
            return DataReturnResult.failure("0003", "评论帖子id不能为空");
        }
        if (ToolUtils.isBlank(machineComment.getContent())) {
            return DataReturnResult.failure("0003", "评论内容不能为空");
        }
       /* if (ToolUtils.isBlank(machineComment.getDestId())){
            return DataReturnResult.failure("0003","评论人id不能为空");
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String datetime = sdf.format(date);
        machineComment.setUpdatetime(datetime);
        machineComment.setIsDelete(false);
        //敏感词过滤
        Map<String, Object> map = userInfoController.getAccessToken(machineComment.getContent());
        if (null != map) {
            int errcode = (int) map.get("errcode");
            if (errcode == 0) {
                int i = machineCommentService.sendCommemt(machineComment);
                if (i == 0) {
                    return DataReturnResult.failure("0003", "评论失败");
                }
                return DataReturnResult.success(i);
            }
            if (errcode == 87014) {
                return DataReturnResult.failure("0003", "内容含有违法违规内容");
            }
            return DataReturnResult.failure("0003", "评论失败");
        }
        return DataReturnResult.failure("0003", "评论失败");
    }

    /**
     * 删除农师贴评论
     *
     * @param uid
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delComment", method = RequestMethod.DELETE)
    public DataReturnResult delComment(String uid) {
        if (ToolUtils.isBlank(uid)) {
            return DataReturnResult.failure("0003", "删除id为空");
        }
        int i = machineCommentService.delComment(uid);
        if (i == 0) {
            return DataReturnResult.failure("0003", "删除失败,请重试");
        }
        return DataReturnResult.success(i);
    }

}
