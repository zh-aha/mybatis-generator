package com.sungolden.wxapp.controller;

import com.sungolden.wxapp.config.AuthCheck;
import com.sungolden.wxapp.dto.AgriPolitics;
import com.sungolden.wxapp.service.AgriPoliticscService;
import com.sungolden.wxapp.service.FavoriteService;
import com.sungolden.wxapp.service.RedisService;
import com.sungolden.wxapp.utils.DataReturnResult;
import com.sungolden.wxapp.utils.DateUtil;
import com.sungolden.wxapp.utils.IpUtil;
import com.sungolden.wxapp.utils.ToolUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 农政接口类
 * @Author: zh
 * @CreateDate: 2019/11/18 14:57
 * @UpdateUser: zh
 * @UpdateDate: 2019/11/18 14:57
 * @UpdateRemark: 修改内容
 * @Version: 1.0
 */
@RestController
@Component
@CrossOrigin(value = "*", maxAge = 3600)
@RequestMapping(value = "/app/agri_politics")
public class AgriPoliticscController {


    Map<String, Integer> map = new HashMap<>();
    @Autowired
    private AgriPoliticscService agriPoliticscService;
    @Autowired
    private FavoriteService favoriteService;
    @Autowired
    private RedisService redisService;

    /**
     * 所有农政新闻列表 按时间倒序
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getPoliticsList", method = RequestMethod.GET)
    public DataReturnResult getPoliticsList(Integer userId) {
        if (null == userId) {
            List<AgriPolitics> agriPoliticsList = agriPoliticscService.getPoliticsList();
            agriPoliticsList.forEach(n -> {
                //boolean favorite = favoriteService.isFavorite(n.getUid(), userId);
                n.setFavorite(false);
            });
            return DataReturnResult.success(agriPoliticsList);
        }
        List<AgriPolitics> agriPoliticsList = agriPoliticscService.getPoliticsList();
        agriPoliticsList.forEach(n -> {
            boolean favorite = favoriteService.isFavorite(n.getUid(), userId);
            n.setFavorite(favorite);
        });
        return DataReturnResult.success(agriPoliticsList);
    }

    /**
     * 所有首页新闻列表 按时间倒序
     *
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getIndexNews", method = RequestMethod.GET)
    public DataReturnResult getIndexNews() {
        List<AgriPolitics> indexNews = agriPoliticscService.getIndexNews();
        return DataReturnResult.success(indexNews);
    }

    /**
     * 根据uid获取详细内容并统计访问量
     *
     * @param uid
     * @return
     */
    //@AuthCheck
    @RequestMapping(value = "/getByUid", method = RequestMethod.GET)
    public DataReturnResult getByUid(String uid, Integer count, HttpServletRequest request) {
        //获取IP地址
        String ipAddr = IpUtil.getIpAddr(request);
        if (ToolUtils.isBlank(uid) || ToolUtils.isBlank(count)) {
            return DataReturnResult.failure("0003", "参数异常");
        }
        //根据ip地址查询该地址是否在两分钟再次访问过该接口
        String key = "ip:" + ipAddr + "-" + uid;
        Object obj = redisService.getObj(key);
        if (null == obj) {
            //无此ip记录  阅读量加1
            count = count + 1;
            //数据库更新访问量
            agriPoliticscService.updateCount(count, uid);
            //记录此ip地址 写入redis
            redisService.setObj(key, key, 60 * 2);
            //返回结果
            AgriPolitics agri = agriPoliticscService.getByUid(uid);
            return DataReturnResult.success(agri);
        } else {
            String key_val = (String) obj;
            String[] split = key_val.split("-");
            String ip = split[0];
            String id = split[1];
            int length = ip.length();
            if (ip.contains("ip")) {
                String substring = ip.substring(2, length);
                if (ipAddr.equals(substring)) {
                    if (uid.equals(id)) {
                        //此条记录被同一个人两分钟内访问过  直接返回数据 count不增加
                        AgriPolitics agri = agriPoliticscService.getByUid(uid);
                        return DataReturnResult.success(agri);
                    }
                    //数据库更新访问量
                    agriPoliticscService.updateCount(count, uid);
                }
            }
            AgriPolitics agri = agriPoliticscService.getByUid(uid);
            return DataReturnResult.success(agri);
        }
    }

    /**
     * 发布农政数据
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public DataReturnResult postData(@RequestBody AgriPolitics agriPolitics) {

        if (null == agriPolitics) {
            return DataReturnResult.failure("0003", "提交数据不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getUserId())) {
            return DataReturnResult.failure("0003", "发布人编号不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getTitle())) {
            return DataReturnResult.failure("0003", "标题不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getThumbnail())) {
            return DataReturnResult.failure("0003", "缩略图不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getContent())) {
            return DataReturnResult.failure("0003", "内容不能为空");
        }
        agriPolitics.setIsDelete(false);
        agriPolitics.setUpdatetime(DateUtil.getNow());
        agriPolitics.setViewCount(0);
        int i = agriPoliticscService.postData(agriPolitics);
        return DataReturnResult.success(i);
    }

    /**
     * 编辑
     *
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public DataReturnResult update(@RequestBody AgriPolitics agriPolitics) {

        if (null == agriPolitics) {
            return DataReturnResult.failure("0003", "提交数据不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getUid())) {
            return DataReturnResult.failure("0003", "编号不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getUserId())) {
            return DataReturnResult.failure("0003", "发布人编号不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getTitle())) {
            return DataReturnResult.failure("0003", "标题不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getThumbnail())) {
            return DataReturnResult.failure("0003", "缩略图不能为空");
        }
        if (ToolUtils.isBlank(agriPolitics.getContent())) {
            return DataReturnResult.failure("0003", "内容不能为空");
        }
        agriPolitics.setUpdatetime(DateUtil.getNow());
        int i = agriPoliticscService.update(agriPolitics);
        return DataReturnResult.success(i);
    }

    /**
     * 删除
     *
     * @param uids
     * @return
     */
    @AuthCheck
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public DataReturnResult delete(String[] uids) {
        int i = agriPoliticscService.delete(uids);
        return DataReturnResult.success(i);
    }
}
